// miniprogram/pages/article/article.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    _openid: '',
    writer: {},
    article: {},
    lock: {
      load: true,
      like: false
    }
  },
  
  timeFormat: function (time) {
    var year = time.getFullYear()
    var month = time.getMonth() + 1
    var date = time.getDate()
    var hour = time.getHours()
    var minute = time.getMinutes()
    var timeFormat = `${year}-${month}-${date} ${hour}:${minute}`
    return timeFormat
  },
  
  onPreviewImage: function (e) {
    var index = e.currentTarget.dataset.index
    wx.previewImage({
      urls: this.data.article.imgList,
      current: this.data.article.imgList[index]
    })
  },

  onEdit: function (e) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '是否前往编辑',
      success: res => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/edit/edit?id=' + that.data.article._id
          })
        }
      }
    })
  },

  onDelete: function (e) {
    var that = this
    wx.showModal({
      title: '提示',
      content: '是否删除文章，操作不可撤回',
      success: res => {
        if (res.confirm) {
          wx.showLoading({
            title: '删除中',
            mask: true
          })
          wx.cloud.callFunction({
            name: 'article',
            data: {
              type: 'delete',
              params: {
                _id: that.data.article._id
              }
            }
          }).then(res => {
            console.log(res)
            console.log('article: 删除文章成功')
            var pages = getCurrentPages()
            var articleList = pages[pages.length - 2].data.articleList
            articleList.splice(that.data.index, 1)
            setTimeout(() => {
              wx.showToast({
                title: '删除文章成功',
                icon: 'none'
              })
            }, 100)
            that.setData({
              writer: {},
              article: {},
              'lock.load': true
            })
            wx.hideLoading()
            wx.navigateBack()
          }).catch(err => {
            console.log(err)
            console.log('article: 删除文章失败，请重试')
            wx.showToast({
              title: '删除文章失败，请重试',
              icon: 'none'
            })
            wx.hideLoading()
          })
        }
      }
    })
  },

  onLike: function (e) {
    var that = this
    if (that.data.lock.load || that.data.lock.like)
      return
    if (!app.globalData.userinfo.register) {
      wx.showModal({
        title: '提示',
        content: '该功能需要注册后使用，是否前往注册',
        success: res => {
          if (res.confirm) {
            wx.switchTab({
              url: '/pages/my/my'
            })
          }
        }
      })
      return
    }
    that.data.lock.like = true
    that.setData({
      'article.liked': !that.data.article.liked,
      'article.likedCount': that.data.article.likedCount + (1 - 2 * that.data.article.liked)
    })
    wx.cloud.callFunction({
      name: 'article',
      data: {
        type: 'modify',
        params: {
          _id: that.data.article._id,
          liked: !that.data.article.liked
        }
      }
    }).then(res => {
      if (that.data.article.liked) {
        console.log('article: 点赞成功')
      } else {
        console.log('article: 取消点赞成功')
      }
      that.data.lock.like = false
      if (that.data.index) {
        var pages = getCurrentPages()
        var articleList = pages[pages.length - 2].data.articleList
        articleList[that.data.index].liked = that.data.article.liked
        articleList[that.data.index].likedCount = that.data.article.likedCount
      }
    }).catch(err => {
      console.log(err)
      if (that.data.article.liked) {
        console.log('article: 点赞失败，请重试')
        wx.showToast({
          title: '点赞失败，请重试',
          icon: 'none'
        })
      } else {
        console.log('article: 取消点赞失败，请重试')
        wx.showToast({
          title: '取消点赞失败，请重试',
          icon: 'none'
        })
      }
      that.setData({
        'article.liked': !that.data.article.liked,
        'article.likedCount': that.data.article.likedCount + (1 - 2 * that.data.article.liked)
      })
      that.data.lock.like = false
    })
  },

  onAvatar: function (e) {
    if (!this.data.lock.load && !this.data.article.anonymous) {
      if (this.data.writer._openid == this.data._openid) {
        wx.showToast({
          title: '请不要试图看你自己',
          icon: 'none'
        })
      } else {
        wx.navigateTo({
          url: '/pages/card/card?openid=' + this.data.article.writer
        })
      }
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var _id = options.id
    that.setData({
      _openid: app.globalData.userinfo._openid
    })
    // 用于修改上一页面渲染
    if (options.index) {
      that.setData({
        index: options.index
      })
    }
    // 加载文章信息
    wx.cloud.callFunction({
      name: 'article',
      data: {
        type: 'get',
        params: {
          type: 'byId',
          _id: _id
        }
      }
    }).then(res => {
      console.log('article: 加载文章信息成功')
      var article = res.result.data
      article.content = article.content
      article.liked = article.like.includes(app.globalData.userinfo._openid)
      article.likedCount = article.like.length
      article.timeFormat = that.timeFormat(new Date(article.time))
      that.setData({
        article: article
      })
      // 是否需要加载作者
      if (!article.anonymous) {
        wx.cloud.callFunction({
          name: 'db',
          data: {
            type: 'check',
            params: {
              _openid: article.writer
            }
          }
        }).then(res => {
          console.log('article: 加载作者信息成功')
          that.setData({
            writer: res.result.data[0],
            'lock.load': false
          })
        }).catch(err => {
          console.log(err)
          console.log('article: 加载作者信息失败，请重试')
          wx.showToast({
            title: '加载作者信息失败，请重试',
            icon: 'none'
          })
        })
      } else {
        that.setData({
          'lock.load': false
        })
      }
      wx.cloud.callFunction({
        name: 'admin',
        data: {}
      }).then(res => {
        that.setData({
          isAdmin: res.result.isAdmin
        })
      })
    }).catch(err => {
      console.log(err)
      console.log('article: 加载文章信息失败，请重试')
      wx.showToast({
        title: '加载文章信息失败，请重试',
        icon: 'none'
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      article: this.data.article
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})