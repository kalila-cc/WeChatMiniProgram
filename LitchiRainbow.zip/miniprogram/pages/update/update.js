// pages/update/update.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    sex: [],
    age: [],
    height: [],
    weight: [],
    floor: [],
    type: [],
    college: [],
    grade: [],
    dorm: [],
    userinfo: {},
    multiArray: [[], []],
    multiIndex: [0, 0],
    isMultiIndexChanged: false,
    lock: {
      confirm: false
    },
    imgLoaded: []
  },

  uploadFile: function (toLoad, loaded) {
    var that = this
    if (toLoad.length == 0) {
      // 上传完成，同步至本地
      var uploadImageIcon = that.data.userinfo.image.pop()
      that.data.userinfo.image = that.data.userinfo.image.concat(loaded)
      that.data.userinfo.image.push(uploadImageIcon)
      that.setData({
        'userinfo.image': that.data.userinfo.image,
        imgLoaded: []
      })
      wx.hideLoading()
      wx.showToast({
        title: '上传成功',
        icon: 'none'
      })
      return
    } else {
      var img = toLoad[0]
      var _openid = that.data.userinfo._openid
      var timestamp = new Date().getTime()
      var suffix = img.slice(img.lastIndexOf('.'))
      var cloudPath = 'LitchiRainbow/imageWall/' + _openid + timestamp + suffix
      wx.cloud.uploadFile({
        cloudPath: cloudPath,
        filePath: img
      }).then(res => {
        toLoad = toLoad.slice(1)
        loaded = loaded.concat([res.fileID])
        that.data.imgLoaded = loaded
        that.uploadFile(toLoad, loaded)
      }).catch(Err => {
        // 上传出错，清除已上传图片
        wx.cloud.deleteFile({
          fileList: loaded
        }).then(res => {
          console.log('update: 因上传出错而执行的对已上传图片的清除成功')
        }).catch(err => {
          console.log(err)
          console.log('update: 因上传出错而执行的对已上传图片的清除失败')
        })
        wx.hideLoading()
        wx.showToast({
          title: '上传失败，请重试',
          icon: 'none'
        })
      })
    }
  },

  onDeleteImage: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index
    wx.showModal({
      title: '提示',
      content: '是否删除该图片',
      success: res => {
        if (res.confirm) {
          wx.cloud.deleteFile({
            fileList: [that.data.userinfo.image[index]]
          }).then(res => {
            console.log('update: 用户主动删除图片成功')
            that.data.userinfo.image.splice(index, 1)
            that.setData({
              'userinfo.image': that.data.userinfo.image
            })
          }).catch(err => {
            console.log(err)
            console.log('update: 用户主动删除图片失败')
            wx.showToast({
              title: '删除失败，请重试',
              icon: 'none'
            })
          })
        }
      }
    })
  },

  onUploadImage: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index
    if (index + 1 == that.data.userinfo.image.length) {
      wx.chooseImage({
        count: 10 - that.data.userinfo.image.length,
        sizeType: ['compressed'],
        success: res => {
          // 尝试通过递归上传至数据库
          wx.showLoading({
            title: '上传中',
            mask: true
          })
          that.uploadFile(res.tempFilePaths, [])
        }
      })
    }      
  },

  onGetUserinfo: function (e) {
    var that = this
    var userinfo = e.detail.userInfo
    if (!that.data.userinfo.avatar) {
      that.setData({
        'userinfo.nickname': userinfo.nickName
      })
      wx.showLoading({
        title: '上传中',
        mask: true
      })
      userinfo.avatarUrl = userinfo.avatarUrl.replace('thirdwx.qlogo.cn', 'wx.qlogo.cn')
      // 自动下载头像
      wx.downloadFile({
        url: userinfo.avatarUrl,
        success: res => {
          // 自动下载头像成功
          var avatar = res.tempFilePath
          var _openid = that.data.userinfo._openid
          var suffix = avatar.slice(avatar.lastIndexOf('.'))
          var cloudPath = 'LitchiRainbow/avatar/' + _openid + suffix
          wx.cloud.uploadFile({
            filePath: avatar,
            cloudPath: cloudPath
          }).then(res => {
            that.setData({
              'userinfo.avatar': res.fileID
            })
            wx.hideLoading()
          }).catch(err => {
            console.log(err)
            console.log('update: 自动上传头像至云存储失败')
            wx.hideLoading()
            wx.showToast({
              title: '自动上传头像失败，请重试(-2)',
              icon: 'none'
            })
          })
        },
        fail: err => {
          console.log(err)
          console.log('update: 自动下载头像失败')
          wx.hideLoading()
          wx.showToast({
            title: '自动上传头像失败，请重试(-1)',
            icon: 'none'
          })
        }
      })
    } else {
      wx.chooseImage({
        count: 1,
        sizeType: ['compressed'],
        success: res => {
          // 读取成功，上传至云存储
          wx.showLoading({
            title: '上传中',
            mask: true
          })
          var avatar = res.tempFilePaths[0]
          var _openid = that.data.userinfo._openid
          var suffix = avatar.slice(avatar.lastIndexOf('.'))
          var cloudPath = 'LitchiRainbow/' + _openid + suffix
          wx.cloud.uploadFile({
            filePath: avatar,
            cloudPath: cloudPath
          }).then(res => {
            that.setData({
              'userinfo.avatar': res.fileID
            })
            wx.hideLoading()
          }).catch(err => {
            console.log(err)
            console.log('update: 自动上传头像至云存储失败')
            wx.hideLoading()
            wx.showToast({
              title: '自动上传头像失败，请重试',
              icon: 'none'
            })
          })
        }
      })
    }
  },

  onConfirm: function (e) {
    var that = this
    if (that.data.lock.confirm)
      return
    that.setData({
      'lock.confirm': true
    })
    var satisfy = true
    var userinfo = that.data.userinfo
    if (!userinfo.register) {
      satisfy = Boolean(satisfy && userinfo.avatar && userinfo.nickname)
      satisfy = Boolean(satisfy && userinfo.age && userinfo.height && userinfo.weight)
      satisfy = Boolean(satisfy && userinfo.type && userinfo.college && userinfo.grade && userinfo.dorm)
      if (satisfy) {
        wx.showLoading({
          title: '加载中',
          mask: true
        })
        var uploadImageIcon = userinfo.image.pop()
        wx.cloud.callFunction({
          name: 'db',
          data: {
            type: 'add',
            params: {
              data: userinfo
            }
          }
        }).then(res => {
          console.log('update: 注册成功')
          wx.hideLoading()
          app.globalData.userinfo = res.result.userinfo
          that.setData({
            'lock.confirm': false
          })
          setTimeout(() => {
            wx.showToast({
              title: '注册成功',
              icon: 'none'
            })
          }, 100)
          wx.switchTab({
            url: '/pages/my/my',
          })
        }).catch(err => {
          console.log(err)
          console.log('update: 注册失败，请重试')
          userinfo.image.push(uploadImageIcon)
          wx.showToast({
            title: '注册失败，请重试',
            icon: 'none'
          })
          that.setData({
            'lock.confirm': false
          })
          wx.hideLoading()
        })
      } else {
        wx.showToast({
          title: '请完整填写必要信息',
          icon: 'none'
        })
        that.setData({
          'lock.confirm': false
        })
      }
    } else {
      if (!userinfo.nickname) {
        wx.showToast({
          title: '请完整填写必要信息',
          icon: 'none'
        })
        that.setData({
          'lock.confirm': false
        })
      } else {
        var uploadImageIcon = that.data.userinfo.image.pop()
        wx.cloud.callFunction({
          name: 'db',
          data: {
            type: 'modify',
            params: {
              data: userinfo
            }
          }
        }).then(res => {
          app.globalData.userinfo = userinfo
          console.log('update: 信息修改成功')
          that.setData({
            'lock.confirm': false
          })
          setTimeout(() => {
            wx.showToast({
              title: '信息修改成功',
              icon: 'none'
            })
          }, 50)
          wx.navigateBack()
        }).catch(err => {
          console.log(err)
          console.log('update: 信息修改失败，请重试')
          wx.showToast({
            title: '信息修改失败，请重试',
            icon: 'none'
          })
          that.data.userinfo.image.push(uploadImageIcon)
          that.setData({
            'userinfo.image': that.data.userinfo.image,
            'lock.confirm': false
          })
        })
      }
    }
  },

  onInput: function (e) {
    var type = e.currentTarget.dataset.type
    var key = `userinfo.${type}`
    var value = e.detail.value
    this.setData({
      [key]: value
    })
  },

  onPickerChange: function (e) {
    var type = e.currentTarget.dataset.type
    var index = e.detail.value
    var key = `userinfo.${type}`
    var value = this.data[type][index]
    if (key === 'userinfo.sex') {
      if (this.data.userinfo.sex != value) {
        this.setData({
          type: ["不介意"].concat(app.globalData.type[value == '女' ? 'F' : 'M'].slice(1)),
          'userinfo.type': '--'
        })
      }
    } else if (key === 'userinfo.type') {
      value = value.replace("不介意", "--")
    } else if (key === 'userinfo.floor' && typeof(value) === 'string') {
      value = 0
    }
    this.setData({
      [key]: value
    })
  },
  
  onMultiPickerChange: function (e) {
    var multiIndex = e.detail.value
    this.setData({
      multiIndex: multiIndex,
      'userinfo.dorm': this.data.multiArray[0][multiIndex[0]].classes[multiIndex[1]].name
    })
  },

  onMultiPickerColumnChange: function (e) {
    if (e.detail.column == 0) {
      this.setData({
        'multiArray[1]': this.data.dorm[e.detail.value].classes
      });
    }
  },

  init: function (options) {
    // 浅拷贝 userinfo
    var userinfo = {}
    for (let key in app.globalData.userinfo) {
      userinfo[key] = app.globalData.userinfo[key]
    }
    userinfo.image = userinfo.image.concat(['/images/uploadImage.png'])
    // 载入 sex, age, hright, weight, floor, dorm, college, type, grade
    var sex = app.globalData.sex
    var age = app.globalData.age
    var height = app.globalData.height
    var weight = app.globalData.weight
    var floor = ["保密"].concat(app.globalData.floor)
    var dorm = app.globalData.dorm
    var college = app.globalData.college
    var type = ["不介意"].concat(app.globalData.type[app.globalData.userinfo.sex == '女' ? 'F' : 'M'].slice(1))
    var grade = app.globalData.grade
    // 设置
    this.setData({
      sex: sex,
      age: age,
      height: height,
      weight: weight,
      floor: floor,
      dorm: dorm,
      college: college,
      type: type,
      grade: grade,
      userinfo: userinfo,
      'multiArray[0]': dorm,
      'multiArray[1]': dorm[0].classes
    })
    var that = this
    wx.cloud.callFunction({
      name: 'admin',
      data: {}
    }).then(res => {
      if (res.result.isAdmin) {
        dorm = [{
          name: "保密",
          classes: [{
            name: "保密"
          }]
        }].concat(dorm)
        that.setData({
          dorm: dorm,
          'multiArray[0]': dorm,
          'multiArray[1]': dorm[0].classes
        })
      }
    })
  },

  wait: function (options) {
    var that = this
    var recursion = () => {
      if (!app.globalData.loaded) {
        setTimeout(recursion, 50)
      } else {
        that.init(options)
      }
    }
    recursion()
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.wait(options)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    // 直接退出页面，清除已上传图片
    if (this.data.imgLoaded.length) {
      wx.cloud.deleteFile({
        fileList: this.data.imgLoaded
      }).then(res => {
        console.log('update: 因直接退出页面而执行的对已上传图片的清除成功')
      }).catch(err => {
        console.log(err)
        console.log('update: 因直接退出页面而执行的对已上传图片的清除失败')
      })
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})