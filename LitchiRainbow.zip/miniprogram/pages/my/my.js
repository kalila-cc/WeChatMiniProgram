// miniprogram/pages/my/my.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userinfo: {}
  },

  onFollow: function (e) {
    if (!app.globalData.userinfo.register) {
      wx.showModal({
        title: '提示',
        content: '该功能需要注册后使用，是否前往注册',
        success: res => {
          if (res.confirm) {
            wx.switchTab({
              url: '/pages/my/my'
            })
          }
        }
      })
      return
    }
    wx.navigateTo({
      url: '/pages/msgbox/msgbox?type=follow'
    })
  },

  onPreviewImage: function (e) {
    var index = e.currentTarget.dataset.index
    wx.previewImage({
      urls: this.data.userinfo.image,
      current: this.data.userinfo.image[index]
    })
  },

  onArticle: function (e) {
    if (!app.globalData.userinfo.register) {
      wx.showModal({
        title: '提示',
        content: '该功能需要注册后使用，是否前往注册',
        success: res => {
          if (res.confirm) {
            wx.switchTab({
              url: '/pages/my/my'
            })
          }
        }
      })
      return
    }
    wx.navigateTo({
      url: '/pages/articlebox/articlebox?type=self'
    })
  },
  
  onNavigateToUpdate: function (e) {
    var type = e.currentTarget.dataset.type
    if (type === 'avatar' || type === 'register') {
      wx.navigateTo({
        url: '/pages/update/update'
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var recursion = res => {
      if (app.globalData.loaded) {
        that.setData({
          loaded: true,
          userinfo: app.globalData.userinfo,
          followedCount: app.globalData.userinfo.followed.length
        })
      } else {
        setTimeout(recursion, 50)
      }
    }
    recursion()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      userinfo: app.globalData.userinfo
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})