// miniprogram/pages/chat/chat.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    self: {},
    userinfo: {},
    msgList: [],
    lock: {
      load: false,
      send: false
    },
    content: ''
  },

  onSend: function (e) {
    var that = this
    if (!that.data.content) {
      wx.showToast({
        title: '内容不能为空',
        icon: 'none'
      })
    } else {
      if (that.data.lock.send)
        return
      that.data.lock.send = true
      wx.showLoading({
        title: '发送中',
        mask: true
      })
      wx.cloud.callFunction({
        name: 'msg',
        data: {
          type: 'set',
          params: {
            data: {
              from: that.data.self._openid,
              to: that.data.userinfo._openid,
              content: that.data.content
            }
          }
        }
      }).then(res => {
        console.log('chat: 消息发送成功')
        var time = new Date(res.result.data.time)
        res.result.data.timeFormat = that.timeFormat(time)
        that.data.msgList.push(res.result.data)
        that.setData({
          msgList: that.data.msgList,
          content: ''
        })
        that.data.lock.send = false
        wx.hideLoading()
      }).catch(err => {
        console.log(err)
        console.log('chat: 消息发送失败，请重试')
        wx.hideLoading()
        wx.showToast({
          title: '消息发送失败，请重试',
          icon: 'none'
        })
        that.data.lock.send = false
      })
    }
  },

  onInput: function (e) {
    var content = e.detail.value
    this.setData({
      content: content
    })
  },

  timeFormat: function (time) {
    var month = time.getMonth() + 1
    var date = time.getDate()
    var hour = time.getHours()
    var minute = time.getMinutes()
    var timeFormat = `${month}-${date} ${hour}:${minute}`
    return timeFormat
  },

  loadData: function () {
    var that = this
    if (that.data.lock.load)
      return
    that.setData({
      'lock.load': true
    })
    var params = {
      count: that.data.msgList.length,
      both: [that.data.self._openid, that.data.userinfo._openid]
    }
    if (params.count > 0) {
      params.oldest = that.data.msgList[0].time
      params.latest = that.data.msgList[params.count - 1].time
    }
    wx.cloud.callFunction({
      name: 'msg',
      data: {
        type: 'get',
        params: params
      }
    }).then(res => {
      console.log('chat: 加载消息列表成功')
      var msgList = that.data.msgList
      var count = that.data.msgList.length
      if (res.result.data.length === 0) {
        // 没有更多数据
        wx.showToast({
          title: '没有更多啦',
          icon: 'none'
        })
      } else {
        // 时间格式化
        for (let i = 0; i < res.result.data.length; i++) {
          let time = new Date(res.result.data[i].time)
          res.result.data[i].timeFormat = that.timeFormat(time)
        }
        // 合并数据并排序
        msgList = msgList.concat(res.result.data)
        msgList.sort((a, b) => a.time - b.time)
        // 设置数据
        that.setData({
          msgList: msgList
        })
        // 是否需要滚动到底部
        if (count == 0) {
          wx.createSelectorQuery().select('.main').boundingClientRect(rect => {
            wx.pageScrollTo({
              duration: 1000,
              scrollTop: rect.bottom
            })
          }).exec()
        }
      }
      that.setData({
        'lock.load': false
      })
    }).catch(err => {
      console.log(err)
      console.log('chat: 加载消息列表失败，请重试')
      wx.showToast({
        title: '加载消息列表失败，请重试',
        icon: 'none'
      })
      that.setData({
        'lock.load': false
      })
    })
  },

  init: function (openid) {
    var that = this
    that.setData({
      self: app.globalData.userinfo
    })
    // 加载对方信息
    wx.cloud.callFunction({
      name: 'db',
      data: {
        type: 'check',
        params: {
          _openid: openid
        }
      }
    }).then(res => {
      console.log('chat: 加载对方信息成功')
      var userinfo = res.result.data[0]
      that.setData({
        userinfo: userinfo
      })
      wx.setNavigationBarTitle({
        title: userinfo.nickname
      })
      // 加载消息列表
      that.loadData()
    }).catch(err => {
      console.log(err)
      console.log('chat: 加载对方信息失败')
      wx.showToast({
        title: '加载用户信息失败，请重试',
        icon: 'none'
      })
    })
  },

  wait: function (openid) {
    var that = this
    var recursion = () => {
      if (!app.globalData.loaded) {
        setTimeout(recursion, 50)
      } else {
        that.init(openid)
      }
    }
    recursion()
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.wait(options.openid)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var that = this
    if (that.data.lock.load)
      return
    that.loadData()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})