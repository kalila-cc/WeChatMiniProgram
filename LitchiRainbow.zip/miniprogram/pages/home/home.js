// miniprogram/pages/home/home.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    self: {},
    userList: [],
    swiperItems: [],
    dorm: [],
    college: [],
    typeCheckbox: [],
    gradeCheckbox: [],
    multiArray: [[], []],
    multiIndex: [0, 0],
    collegeIndex: 0,
    typeCache: [],
    gradeCache: [],
    condition: {},
    lock: {
      select: true,
      confirm: false,
      load: false,
      loadFinished: false
    }
  },

  onCard: function (e) {
    var openid = e.currentTarget.dataset.openid
    wx.navigateTo({
      url: '/pages/card/card?openid=' + openid
    })
  },

  onConfirmCondition: function (e) {
    var that = this
    if (that.data.lock.confirm)
      return
    that.setData({
      'lock.confirm': true
    })
    var satisfy = false
    var tmp_condition = {}
    for (let key in that.data.condition) {
      tmp_condition[key] = that.data.condition[key]
    }
    if (that.data.collegeIndex > 0) {
      satisfy = true
      tmp_condition.college = that.data.college[that.data.collegeIndex]
    }
    if (that.data.multiIndex[0] > 0) {
      satisfy = true
      tmp_condition.dorm = that.data.multiArray[0][that.data.multiIndex[0]].classes[that.data.multiIndex[1]].name
    }
    if (that.data.typeCache.length > 0) {
      satisfy = true
      if (that.data.typeCache.length < that.data.typeCheckbox.length) {
        tmp_condition.type = that.data.typeCache
      }
    }
    if (that.data.gradeCache.length > 0) {
      satisfy = true
      if (that.data.gradeCache.length < that.data.gradeCheckbox.length) {
        tmp_condition.grade = that.data.gradeCache
      }
    }
    that.setData({
      condition: satisfy ? tmp_condition : {
        sex: that.data.self.sex || '男'
      }
    }, () => {
      wx.showLoading({
        title: '搜索中',
        mask: true
      })
      that.loadData({
        count: 0,
        condition: that.data.condition
      })
    })
  },

  onTypeChange: function (e) {
    this.data.typeCache = e.detail.value
  },

  onGradeChange: function (e) {
    this.data.gradeCache = e.detail.value
  },

  onCanSelect: function (e) {
    if (!this.data.lock.select) {
      this.setData({
        typeCache: [],
        gradeCache: []
      })
    }
    this.setData({
      'lock.select': !this.data.lock.select
    })
  },

  onCollegeChange: function (e) {
    this.setData({
      collegeIndex: e.detail.value
    })
  },

  onMultiPickerChange: function (e) {
    this.setData({
      multiIndex: e.detail.value
    })
  },

  onMultiPickerColumnChange: function (e) {
    if (e.detail.column == 0) {
      this.setData({
        'multiArray[1]': this.data.dorm[e.detail.value].classes,
      });
    }
  },

  loadData: function (params) {
    var that = this
    that.setData({
      'lock.load': true
    })
    wx.cloud.callFunction({
      name: 'db',
      data: {
        type: 'check',
        params: params
      }
    }).then(res => {
      console.log('home: 加载数据成功')
      var userList = that.data.userList
      var isLoadFinished = false
      if (params.count > 0) {
        userList = userList.concat(res.result.data)
      } else {
        userList = res.result.data
      }
      if (res.result.data.length === 0) {
        isLoadFinished = true
      }
      that.setData({
        userList: userList,
        typeCache: [],
        gradeCache: [],
        'lock.select': true,
        'lock.loadFinished': isLoadFinished,
        'lock.load': false,
        'lock.confirm': false
      })
      wx.hideLoading()
    }).catch(err => {
      console.log('home: 加载数据失败，请重试')
      wx.showToast({
        title: '加载数据失败，请重试',
        icon: 'none'
      })
      that.setData({
        'lock.load': false,
        'lock.confirm': false
      })
      wx.hideLoading()
    })
  },

  evaluate: function () {
    var that = this
    // 检查是否成功登录以及是否注册
    var recursion = () => {
      if (!app.globalData.loaded) {
        setTimeout(recursion, 50)
      } else {
        if (!app.globalData.logged) {
          setTimeout(() => {
            wx.showToast({
              title: '未能成功自动登录，请尝试重启',
              icon: 'none'
            })
          }, 100)
          wx.switchTab({
            url: '/pages/my/my',
          })
        } else {
          that.setData({
            self: app.globalData.userinfo,
            condition: {
              sex: app.globalData.userinfo.sex || '男'
            }
          })
        }
      }
    }
    recursion()
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.evaluate()
    // 分别载入 dorm, college, type, grade
    var dorm = [{
      name: "不限",
      classes: [{
        name: "不限"
      }]
    }].concat(app.globalData.dorm)
    var college = ["不限"].concat(app.globalData.college)
    var typeCheckbox = []
    var type_ = app.globalData.type[app.globalData.userinfo.sex == '女' ? 'F' : 'M']
    for (let i = 0; i < type_.length; i++) {
      typeCheckbox.push({
        value: type_[i],
        checked: false
      })
    }
    var gradeCheckbox = []
    for (let i = 0; i < app.globalData.grade.length; i++) {
      gradeCheckbox.push({
        value: app.globalData.grade[i],
        checked: false
      })
    }
    // 设置 dorm, college, type, grade
    this.setData({
      dorm: dorm,
      college: college,
      typeCheckbox: typeCheckbox,
      gradeCheckbox: gradeCheckbox,
      "multiArray[0]": dorm,
      "multiArray[1]": dorm[0].classes
    })
    // 载入轮播图
    var that = this
    wx.cloud.callFunction({
      name: 'img',
      data: {
        type: 'swiper'
      }
    }).then(res => {
      that.setData({
        swiperItems: res.result.data
      })
    })
    // 加载数据
    this.loadData({
      count: 0,
      condition: {
        sex: app.globalData.userinfo.sex || '男'
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.evaluate()
    var typeCheckbox = []
    var type = app.globalData.type[app.globalData.userinfo.sex == '女' ? 'F' : 'M']
    for (let i = 0; i < type.length; i++) {
      typeCheckbox.push({
        value: type[i],
        checked: false
      })
    }
    this.setData({
      typeCheckbox: typeCheckbox
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.loadData({
      count: 0,
      condition: this.data.condition
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (!this.data.lock.loadFinished) {
      this.loadData({
        count: this.data.userList.length,
        condition: this.data.condition
      })
    } else {
      wx.showToast({
        title: '没有更多啦',
        icon: 'none'
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})