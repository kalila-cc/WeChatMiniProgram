// miniprogram/pages/msgbox/msgbox.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    switchIndex: 0,
    userList: [],
    isLoadFinished: false,
    lock: {
      load: false
    }
  },

  onSwitch: function (e) {
    var index = e.currentTarget.dataset.index
    this.setData({
      switchIndex: index
    })
  },

  onItem: function (e) {
    var that = this
    var openid = e.currentTarget.dataset.openid
    var index = e.currentTarget.dataset.index
    if (that.data.type == 'chat') {
      wx.navigateTo({
        url: `/pages/chat/chat?openid=${openid}`
      })
    } else if (that.data.type == 'follow') {
      wx.navigateTo({
        url: `/pages/card/card?from=msgbox&openid=${openid}&index=${index}`
      })
    }
  },

  loadData: function (isLazyload) {
    var that = this
    if (that.data.lock.load)
      return
    that.setData({
      'lock.load': true
    })
    if (that.data.type == 'chat') {
      wx.cloud.callFunction({
        name: 'msg',
        data: {
          type: 'preview',
          params: {
            count: isLazyload ? that.data.userList.length : 0
          }
        }
      }).then(res => {
        console.log('msgbox: 加载会话列表成功')
        var userList = res.result.data
        if (userList.length == 0) {
          that.setData({
            isLoadFinished: true
          })
        }
        if (isLazyload && userList.length) {
          userList = that.data.userList.concat(userList)
        }
        that.setData({
          userList: userList,
          'lock.load': false
        })
      }).catch(err => {
        console.log(err)
        console.log('msgbox: 加载会话列表失败，请重试')
        wx.showToast({
          title: '加载会话列表失败，请重试',
          icon: 'none'
        })
        that.setData({
          'lock.load': false
        })
      })
    } else if (that.data.type == 'follow') { 
      wx.cloud.callFunction({
        name: 'db',
        data: {
          type: 'check',
          params: {
            follow: true,
            count: isLazyload ? that.data.userList.length : 0
          }
        }
      }).then(res => {
        var userList = res.result.data
        if (userList.length == 0) {
          that.setData({
            isLoadFinished: true
          })
        } else {
          for (let i = 0; i < userList.length; i++) {
            let follow = that.data.self.follow.includes(userList[i]._openid)
            let followed = that.data.self.followed.includes(userList[i]._openid)
            if (follow) {
              userList[i].switchIndex = 0
            } else if (followed) {
              userList[i].switchIndex = 1
            }
            if (follow && followed) {
              userList[i].switchIndex = 2
            }
          }
        }
        if (isLazyload && userList.length) {
          userList = that.data.userList.concat(userList)
        }
        console.log('msgbox: 加载关注列表成功')
        that.setData({
          userList: userList,
          'lock.load': false
        })
      }).catch(err => {
        console.log(err)
        console.log('msgbox: 加载关注列表失败，请重试')
        wx.showToast({
          title: '加载关注列表失败，请重试',
          icon: 'none'
        })
        that.setData({
          'lock.load': false
        })
      })
    }
  },

  init: function () {
    this.loadData(false)
  },

  wait: function () {
    var that = this
    var recursion = () => {
      if (!app.globalData.loaded) {
        setTimeout(recursion, 50)
      } else {
        that.init()
      }
    }
    recursion()
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      self: app.globalData.userinfo
    })
    if (options.type == 'chat') {
      wx.setNavigationBarTitle({
        title: '消息盒子'
      })
      this.setData({
        type: 'chat'
      })
    } else if (options.type == 'follow') {
      wx.setNavigationBarTitle({
        title: '关注列表'
      })
      this.setData({
        type: 'follow'
      })
    }
    this.wait()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      userList: this.data.userList
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.loadData(false)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.loadData(true)
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})