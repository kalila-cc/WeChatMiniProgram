// miniprogram/pages/articlebox/articlebox.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    type: '',
    self: {},
    _openid: '',
    articleList: [],
    isLoadFinished: false,
    lock: {
      load: false
    }
  },

  timeFormat: function (time) {
    var year = time.getFullYear()
    var month = time.getMonth() + 1
    var date = time.getDate()
    var hour = time.getHours()
    var minute = time.getMinutes()
    var timeFormat = `${year}-${month}-${date} ${hour}:${minute}`
    return timeFormat
  },

  onWriteArticle: function (e) {
    if (!app.globalData.userinfo.register) {
      wx.showModal({
        title: '提示',
        content: '该功能需要注册后使用，是否前往注册',
        success: res => {
          if (res.confirm) {
            wx.switchTab({
              url: '/pages/my/my'
            })
          }
        }
      })
      return
    }
    wx.navigateTo({
      url: '/pages/edit/edit'
    })
  },

  onCard: function (e) {
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    wx.navigateTo({
      url: '/pages/article/article?id=' + id + '&index=' + index
    })
  },

  loadData: function (isLazyload) {
    var that = this
    if (that.data.lock.load)
      return
    that.data.lock.load = true
    var type = that.data.type
    var params = {
      count: isLazyload ? that.data.articleList.length : 0
    }
    if (params.count > 0) {
      params.oldest = that.data.articleList[that.data.articleList.length - 1].time
    }
    if (type === 'self' || type === 'other') {
      params.type = 'byOpenid'
      params._openid = that.data._openid
    } else if (type === 'all') {
      params.type = 'all'
    } else if (type === 'feedback') {
      params.type = 'feedback'
    }
    wx.cloud.callFunction({
      name: 'article',
      data: {
        type: 'get',
        params: params
      }
    }).then(res => {
      console.log('articlebox: 加载文章列表成功')
      var articleList = res.result.data
      if (articleList.length == 0) {
        that.setData({
          isLoadFinished: true
        })
        wx.showToast({
          title: '没有更多啦',
          icon: 'none'
        })
      } else {
        for (let i = 0; i < articleList.length; i++) {
          articleList[i].liked = articleList[i].like.includes(that.data.self._openid)
          articleList[i].likedCount = articleList[i].like.length
          articleList[i].content = articleList[i].content.replace(/\n+/g, ' ')
          articleList[i].timeFormat = that.timeFormat(new Date(articleList[i].time))
        }
        if (params.count > 0) {
          articleList = that.data.articleList.concat(articleList)
        }
        that.setData({
          articleList: articleList
        })
      }
      that.data.lock.load = false
    }).catch(err => {
      console.log(err)
      console.log('articlebox: 加载文章列表失败，请重试')
      wx.showToast({
        title: '加载文章列表失败，请重试',
        icon: 'none'
      })
      that.data.lock.load = false
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    that.setData({
      type: options.type,
      self: app.globalData.userinfo
    })
    if (options.type === 'self') {
      that.setData({
        canWriteArticle: true,
        _openid: app.globalData.userinfo._openid
      })
      wx.setNavigationBarTitle({
        title: '我的文章'
      })
    } else if (options.type === 'other') {
      that.setData({
        _openid: options.openid
      })
      wx.setNavigationBarTitle({
        title: (options.sex == '男' ? '他' : '她') + '的文章'
      })
    } else if (options.type === 'all') {
      wx.setNavigationBarTitle({
        title: '故事汇'
      })
    } else if (options.type === 'feedback') {
      that.setData({
        feedback: true
      })
      wx.setNavigationBarTitle({
        title: '后台反馈'
      })
    }
    that.loadData(false)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      articleList: this.data.articleList
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.loadData(false)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.isLoadFinished) {
      wx.showToast({
        title: '没有更多啦',
        icon: 'none'
      })
    } else {
      this.loadData(true)
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})