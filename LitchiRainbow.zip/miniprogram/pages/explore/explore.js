// miniprogram/pages/explore/explore.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  onFunc: function (e) {
    var type = e.currentTarget.dataset.type
    if (type == 'articlebox') {
      wx.navigateTo({
        url: '/pages/articlebox/articlebox?type=all'
      })
    } else if (type == 'msgbox') {
      if (!app.globalData.userinfo.register) {
        wx.showModal({
          title: '提示',
          content: '该功能需要注册后使用，是否前往注册',
          success: res => {
            if (res.confirm) {
              wx.switchTab({
                url: '/pages/my/my'
              })
            }
          }
        })
        return
      }
      wx.navigateTo({
        url: '/pages/msgbox/msgbox?type=chat'
      })
    } else if (type == 'feedback') {
      if (!app.globalData.userinfo.register) {
        wx.showModal({
          title: '提示',
          content: '该功能需要注册后使用，是否前往注册',
          success: res => {
            if (res.confirm) {
              wx.switchTab({
                url: '/pages/my/my'
              })
            }
          }
        })
        return
      }
      wx.navigateTo({
        url: '/pages/edit/edit?feedback=1',
      })
    } else if (type == 'admin') {
      wx.navigateTo({
        url: '/pages/articlebox/articlebox?type=feedback',
      })
    }
  },

  evaluate: function () {
    var that = this
    // 检查是否成功登录以及是否注册
    var recursion = () => {
      if (!app.globalData.loaded) {
        setTimeout(recursion, 50)
      } else {
        if (!app.globalData.logged) {
          setTimeout(() => {
            wx.showToast({
              title: '未能成功自动登录，请尝试重启',
              icon: 'none'
            })
          }, 100)
          wx.switchTab({
            url: '/pages/my/my',
          })
        } else {
          wx.cloud.callFunction({
            name: 'admin',
            data: {}
          }).then(res => {
            that.setData({
              isAdmin: res.result.isAdmin
            })
          })
        }
      }
    }
    recursion()
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.evaluate()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.evaluate()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})