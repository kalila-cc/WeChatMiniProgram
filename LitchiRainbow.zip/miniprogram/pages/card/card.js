// miniprogram/pages/card/card.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    self: {},
    userinfo: {},
    hasFollowed: false,
    hasBeenFollowed: false,
    hasPopUp: !false,
    lock: {
      follow: false
    }
  },
  
  onPreviewImage: function (e) {
    var index = e.currentTarget.dataset.index
    wx.previewImage({
      urls: this.data.userinfo.image,
      current: this.data.userinfo.image[index]
    })
  },

  onArticle: function (e) {
    var openid = this.data.userinfo._openid
    var sex = this.data.userinfo.sex
    wx.navigateTo({
      url: `/pages/articlebox/articlebox?type=other&openid=${openid}&sex=${sex}`
    })
  },

  onChat: function (e) {
    if (!app.globalData.userinfo.register) {
      wx.showModal({
        title: '提示',
        content: '该功能需要注册后使用，是否前往注册',
        success: res => {
          if (res.confirm) {
            wx.switchTab({
              url: '/pages/my/my'
            })
          }
        }
      })
      return
    }
    wx.navigateTo({
      url: '/pages/chat/chat?openid=' + this.data.userinfo._openid,
    })
  },

  onFollow: function (e) {
    var that = this
    if (that.data.lock.follow)
      return
    if (!app.globalData.userinfo.register) {
      wx.showModal({
        title: '提示',
        content: '该功能需要注册后使用，是否前往注册',
        success: res => {
          if (res.confirm) {
            wx.switchTab({
              url: '/pages/my/my'
            })
          }
        }
      })
      return
    }
    that.setData({
      'lock.follow': true,
      hasFollowed: !that.data.hasFollowed,
      followedCount: that.data.followedCount + (1 - 2 * that.data.hasFollowed)
    })
    wx.cloud.callFunction({
      name: 'db',
      data: {
        type: 'modify',
        params: {
          followMap: {
            from: that.data.self._openid,
            to: that.data.userinfo._openid,
            hasFollowed: !that.data.hasFollowed
          }
        }
      }
    }).then(res => {
      console.log('card: 修改关注状态成功')
      wx.showToast({
        title: (that.data.hasFollowed ? '' : '取消') + '关注成功',
        icon: 'none'
      })
      that.setData({
        'lock.follow': false
      })
    }).catch(err => {
      console.log(err)
      console.log('card: 修改关注状态失败，请重试')
      wx.showToast({
        title: (that.data.hasFollowed ? '' : '取消') + '关注失败，请重试',
        icon: 'none'
      })
      that.setData({
        'lock.follow': false,
        hasFollowed: !that.data.hasFollowed,
        followedCount: that.data.followedCount + (1 - 2 * that.data.hasFollowed)
      })
    })
  },

  init: function (_openid) {
    var that = this
    // 先设置 self
    that.setData({
      self: app.globalData.userinfo
    })
    // 读取 _openid 对应用户
    wx.cloud.callFunction({
      name: 'db',
      data: {
        type: 'check',
        params: {
          _openid: _openid
        }
      }
    }).then(res => {
      // 检查是否为其粉丝以及设置人气
      var userinfo = res.result.data[0]
      var hasFollowed = userinfo.followed.includes(that.data.self._openid)
      that.setData({
        userinfo: userinfo,
        hasFollowed: hasFollowed,
        followedCount: userinfo.followed.length
      })
    }).catch(err => {
      console.log(err)
      console.log('card: 加载用户信息失败，请重试')
      wx.showToast({
        title: '加载用户信息失败，请重试',
        icon: 'none'
      })
    })
  },

  wait: function (_openid) {
    var recursion = () => {
      if (!app.globalData.loaded) {
        setTimeout(recursion, 50)
      } else {
        this.init(_openid)
      }
    }
    recursion()
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.from == 'msgbox') {
      this.setData({
        from: 'msgbox',
        index: options.index
      })
    }
    this.wait(options.openid)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    var that = this
    if (that.data.from == 'msgbox') {
      var _openid = that.data.userinfo._openid
      if (!self.follow.includes(_openid) && !self.followed.includes(_openid)) {
        var pages = getCurrentPages()
        var userList = pages[pages.length - 2].data.userList
        userList.splice(that.data.index, 1)
      }
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})