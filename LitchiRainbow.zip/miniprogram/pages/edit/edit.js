// miniprogram/pages/article/article.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    anonymous: false,
    title: '',
    content: '',
    imgList: ['/images/uploadImage.png'],
    backup: {
      added: [],
      removed: []
    },
    lock: {
      confirm: false
    }
  },
  
  uploadFile: function (toLoad, loaded) {
    var that = this
    if (toLoad.length == 0) {
      // 同步至备份
      if (that.data._id) {
        that.data.backup.added = that.data.backup.added.concat(loaded)
      }
      // 上传完成，同步至本地
      var uploadImageIcon = that.data.imgList.pop()
      that.data.imgList = that.data.imgList.concat(loaded)
      that.data.imgList.push(uploadImageIcon)
      that.setData({
        imgList: that.data.imgList,
        imgLoaded: []
      })
      wx.hideLoading()
      wx.showToast({
        title: '上传成功',
        icon: 'none'
      })
      return
    } else {
      var img = toLoad[0]
      var _openid = app.globalData.userinfo._openid
      var timestamp = new Date().getTime()
      var suffix = img.slice(img.lastIndexOf('.'))
      var cloudPath = 'LitchiRainbow/article/' + _openid + timestamp + suffix
      wx.cloud.uploadFile({
        cloudPath: cloudPath,
        filePath: img
      }).then(res => {
        toLoad = toLoad.slice(1)
        loaded = loaded.concat([res.fileID])
        that.data.imgLoaded = loaded
        that.uploadFile(toLoad, loaded)
      }).catch(Err => {
        // 上传出错，清除已上传图片
        wx.cloud.deleteFile({
          fileList: loaded
        }).then(res => {
          console.log('edit: 因上传出错而执行的对已上传图片的清除成功')
        }).catch(err => {
          console.log(err)
          console.log('edit: 因上传出错而执行的对已上传图片的清除失败')
        })
        wx.hideLoading()
        wx.showToast({
          title: '上传失败，请重试',
          icon: 'none'
        })
      })
    }
  },

  onDeleteImage: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index
    wx.showModal({
      title: '提示',
      content: '是否删除该图片',
      success: res => {
        if (res.confirm) {
          if (that.data._id) {
            // 同步至备份
            that.data.backup.removed.push(that.data.imgList[index])
            that.data.imgList.splice(index, 1)
            that.setData({
              imgList: that.data.imgList
            })
          } else {
            // 直接删除
            wx.cloud.deleteFile({
              fileList: [that.data.imgList[index]]
            }).then(res => {
              console.log('edit: 用户主动删除图片成功')
              that.data.imgList.splice(index, 1)
              that.setData({
                imgList: that.data.imgList
              })
            }).catch(err => {
              console.log(err)
              console.log('edit: 用户主动删除图片失败')
              wx.showToast({
                title: '删除失败，请重试',
                icon: 'none'
              })
            })
          }
        }
      }
    })
  },

  onUploadImage: function (e) {
    var that = this
    var index = e.currentTarget.dataset.index
    if (index + 1 == that.data.imgList.length) {
      wx.chooseImage({
        count: 10 - that.data.imgList.length,
        sizeType: ['compressed'],
        success: res => {
          // 尝试通过递归上传至数据库
          wx.showLoading({
            title: '上传中',
            mask: true
          })
          that.uploadFile(res.tempFilePaths, [])
        }
      })
    }      
  },

  onConfirm: function (e) {
    var that = this
    if (that.data.lock.confirm)
      return
    var satisfy = true
    satisfy = Boolean(satisfy && that.data.title && that.data.content)
    if (satisfy) {
      that.setData({
        'lock.confirm': true
      })
      if (that.data._id) {
        // 修改
        wx.cloud.callFunction({
          name: 'article',
          data: {
            type: 'modify',
            params: {
              _id: that.data._id,
              data: {
                anonymous: that.data.anonymous,
                title: that.data.title,
                content: that.data.content,
                imgList: that.data.imgList.slice(0, that.data.imgList.length - 1)
              }
            }
          }
        }).then(res => {
          // 清除备份中存在的已被删除的图片
          if (that.data.backup.removed.length) {
            wx.cloud.deleteFile({
              fileList: that.data.backup.removed
            }).then(res => {
              console.log('edit: 清除备份中存在的失效图片成功')
            }).catch(err => {
              console.log(err)
              console.log('edit: 清除备份中存在的失效图片失败')
            })
          }
          that.data.backup.added = []
          // 重置上一页渲染层数据
          var pages = getCurrentPages()
          var article = pages[pages.length - 2].data.article
          article.anonymous = that.data.anonymous
          article.title = that.data.title
          article.content = that.data.content
          article.imgList = that.data.imgList.slice(0, that.data.imgList.length - 1)
          // 通知
          console.log('edit: 文章修改成功')
          that.setData({
            'lock.confirm': false
          })
          setTimeout(() => {
            wx.showToast({
              title: ' 文章修改成功',
              icon: 'none'
            })
          }, 100)
          wx.navigateBack()
        }).catch(err => {
          console.log(err)
          console.log('edit: 文章修改失败，请重试')
          wx.showToast({
            title: ' 文章修改失败，请重试',
            icon: 'none'
          })
          that.setData({
            'lock.confirm': false
          })
        })
      } else {
        // 发布/反馈
        wx.cloud.callFunction({
          name: 'article',
          data: {
            type: 'add',
            params: {
              data: {
                type: that.data.feedback ? 'feedback' : 'article',
                anonymous: that.data.anonymous,
                writer: app.globalData.userinfo._openid,
                title: that.data.title,
                content: that.data.content,
                imgList: that.data.imgList.slice(0, that.data.imgList.length - 1),
                like: []
              }
            }
          }
        }).then(res => {
          if (that.data.feedback) {
            console.log('edit: 反馈成功')
          } else {
            console.log('edit: 文章发布成功')
          }
          that.setData({
            imgList: [],
            'lock.confirm': false
          })
          setTimeout(() => {
            if (that.data.feedback) {
              wx.showToast({
                title: ' 反馈成功',
                icon: 'none'
              })
            } else {
              wx.showToast({
                title: ' 文章发布成功',
                icon: 'none'
              })
            }
          }, 100)
          wx.navigateBack()
        }).catch(err => {
          console.log(err)
          if (that.data.feedback) {
            console.log('edit: 反馈失败，请重试')
            wx.showToast({
              title: ' 反馈失败，请重试',
              icon: 'none'
            })
          } else {
            console.log('edit: 文章发布失败，请重试')
            wx.showToast({
              title: ' 文章发布失败，请重试',
              icon: 'none'
            })
          }
          that.setData({
            'lock.confirm': false
          })
        })
      }
        
    } else {
      wx.showToast({
        title: '请完整填写必需项',
        icon: 'none'
      })
    }
  },

  onInput: function (e) {
    var type = e.currentTarget.dataset.type
    var value = e.detail.value
    this.setData({
      [type]: value
    })
  },

  onPickerChange: function (e) {
    this.setData({
      anonymous: !Number(e.detail.value)
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.setNavigationBarTitle({
      title: '编辑'
    })
    if (options.id) {
      that.setData({
        _id: options.id
      })
      wx.cloud.callFunction({
        name: 'article',
        data: {
          type: 'get',
          params: {
            type: 'byId',
            _id: options.id
          }
        }
      }).then(res => {
        console.log('edit: 加载原文章成功')
        var article = res.result.data
        that.setData({
          title: article.title,
          content: article.content.replace(/<\/br>/g, '\n'),
          imgList: article.imgList.concat(that.data.imgList)
        })
      }).catch(err => {
        console.log(err)
        console.log('edit: 加载原文章失败，请重试')
        wx.showToast({
          title: '加载原文章失败，请重试',
          icon: 'none'
        })
      })
    } else if (options.feedback) {
      that.setData({
        feedback: true
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    var that = this
    // 直接退出页面，清除已上传图片
    if (that.data._id) {
      if (that.data.backup.added.length) {
        wx.cloud.deleteFile({
          fileList: that.data.backup.added
        }).then(res => {
          console.log('edit: 因直接退出页面而执行的对备份中的已上传图片的清除成功')
        }).catch(err => {
          console.log(err)
          console.log('edit: 因直接退出页面而执行的对备份中的已上传图片的清除失败')
        })
      }
    } else {
      if (that.data.imgList.length) {
        wx.cloud.deleteFile({
          fileList: that.data.imgList
        }).then(res => {
          console.log('edit: 因直接退出页面而执行的对已上传图片的清除成功')
        }).catch(err => {
          console.log(err)
          console.log('edit: 因直接退出页面而执行的对已上传图片的清除失败')
        })
      }
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})