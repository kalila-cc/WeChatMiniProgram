//app.js
App({
  onLaunch: function () {
    var that = this
    // 云环境初始化
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        env: "xly01-cc001",
        traceUser: true,
      })
    }
    // 生成可能用到的全局数组
    var age = []
    for (let i = 15; i <= 30; i++) {
      age.push(i)
    }
    var height = []
    for (let i = 80; i <= 240; i++) {
      height.push(i)
    }
    var weight = []
    for (let i = 30; i <= 150; i++) {
      weight.push(i)
    }
    var floor = []
    for (let i = 1; i <= 30; i++) {
      floor.push(i)
    }
    // 全局变量
    that.globalData = {
      // 加载信息
      loaded: false,
      // 登录信息
      logged: false,
      // 用户信息
      userinfo: {
        register: false,
        avatar: "",
        nickname: "",
        sex: "",
        age: 0,
        height: 0,
        weight: 0,
        type: "",
        college: "",
        grade: "",
        dorm: "",
        floor: 0,
        intro: "",
        hope: "",
        hate: "",
        image: [],
        follow: [],
        followed: []
      },
      // 宿舍信息
      dorm: [{
        name: "南区",
        classes: [{
          name: "春笛"
        }, {
          name: "夏筝"
        }, {
          name: "秋瑟"
        }, {
          name: "冬筑"
        }]
      }, {
        name: "丽湖校区",
        classes: [{
          name: "风信子"
        }, {
          name: "山楂树"
        }, {
          name: "胡杨林"
        }]
      }, {
        name: "西南阁区",
        classes: [{
          name: "杜衡阁"
        }, {
          name: "辛夷阁"
        },{
          name: "韵竹阁"
        }, {
          name: "芸香阁"
        }, {
          name: "丁香阁"
        }, {
          name: "文杏阁"
        }, {
          name: "海棠阁"
        }, {
          name: "疏影阁"
        }]
      }, {
        name: "西南乔区",
        classes: [{
          name: "乔木阁"
        }, {
          name: "乔林阁"
        },{
          name: "乔森阁"
        }, {
          name: "乔相阁"
        }, {
          name: "乔梧阁"
        }]
      }, {
        name: "西南轩区",
        classes: [{
          name: "丹凤轩"
        }, {
          name: "木犀轩"
        }, {
          name: "紫檀轩"
        }, {
          name: "石楠轩"
        }, {
          name: "苏铁轩"
        }, {
          name: "紫藤轩"
        }, {
          name: "云杉轩"
        }]
      }, {
        name: "西南其他",
        classes: [{
          name: "文山湖"
        }, {
          name: "云鹤楼"
        }, {
          name: "云鹏楼"
        }]
      }, {
        name: "斋区",
        classes: [{
          name: "聚翰斋"
        }, {
          name: "红豆斋"
        }, {
          name: "紫薇斋"
        }, {
          name: "蓬莱客舍"
        }, {
          name: "红榴斋"
        }, {
          name: "海桐斋"
        }, {
          name: "桃李斋"
        }, {
          name: "山茶斋"
        }, {
          name: "米兰斋"
        }, {
          name: "凌霄斋"
        }, {
          name: "雨娟斋"
        }, {
          name: "银桦斋"
        }, {
          name: "风槐斋"
        }]
      }],
      // 学院信息
      college: [
        "马克思主义学院",
        "经济学院",
        "法学院",
        "人文学院",
        "外国语学院",
        "传播学院",
        "数学与统计学院",
        "物理与光电工程学院",
        "化学与环境工程学院",
        "生命与海洋科学学院",
        "机电与控制工程学院",
        "材料学院",
        "电子与信息工程学院",
        "计算机与软件学院",
        "建筑与城市规划学院",
        "土木与交通工程学院",
        "管理学院",
        "高等研究院",
        "金融科技学院",
        "国际交流学院",
        "继续教育学院",
        "教育学部",
        "艺术学部",
        "医学部",
        "体育部"
      ],
      // 类型信息
      type: {
        "M":  ["--", "0", "0.5", "1"],
        "F": ["--", "T", "P", "H"]
      },
      // 年级信息
      grade: ["大一", "大二", "大三", "大四"],
      // 性别信息
      sex: ["男", "女"],
      // 年龄信息
      age: age,
      // 身高信息
      height: height,
      // 体重信息
      weight: weight,
      // 楼层信息
      floor: floor
    }
    // 登录
    wx.cloud.callFunction({
      name: "login",
      data: {}
    }).then(res => {
      if (res.result.data.length === 0) {
        console.log('app: 数据库不存在该用户信息')
        that.globalData.userinfo._openid = res.result._openid
      } else {
        that.globalData.userinfo = res.result.data[0]
        console.log('app: 数据库存在该用户信息，信息更新成功')
      }
      that.globalData.logged = true
      that.globalData.loaded = true
      console.log('app: 自动登录完成')
    }).catch(err => {
      console.log(err)
      console.log('app: 自动登录失败，请尝试重启')
      wx.showToast({
        title: '自自动登录失败，请尝试重启',
        icon: 'none'
      })
      that.globalData.loaded = true
      console.log('app: 自动登录完成')
    })
  }
})
