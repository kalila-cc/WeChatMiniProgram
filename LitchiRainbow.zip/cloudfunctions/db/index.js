// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: "xly01-cc001"
})

const db = cloud.database()
const _ = db.command
const LIMIT = 20
const MAX_LIMIT = 100

// 云函数入口函数
exports.main = async (event, context) => {
  // 以下所有分支都需要传入 event.type
  console.log(event)
  if (event.type === 'add') {
    /**
     * 传入：
     * event.params.data
    */
    event.params.data.register = true
    event.params.data._openid = cloud.getWXContext().OPENID
    return await db.collection('userinfo')
    .add({
      data: event.params.data
    }).then(res => {
      return {
        userinfo: event.params.data
      }
    })
  } else if (event.type === 'check') {
    /**
     * 传入
     * event.params._openid
     * 或
     * event.params.count
     * event.params.follow
     * 或
     * event.params.count
     * event.params.condition (必选 sex | 可选 college, dorm, type, grade
    */
    if (event.params._openid) {
      return await db.collection('userinfo').limit(1).where({
        _openid: event.params._openid
      }).get()
    } else if (event.params.follow) {
      var _openid = cloud.getWXContext().OPENID
      return db.collection('userinfo').limit(1).where({
        _openid: _openid
      }).get().then(res => {
        var self = res.data[0]
        var followList = self.follow.concat(self.followed)
        return db.collection('userinfo').skip(event.params.count).limit(LIMIT)
        .where({
          _openid: _.in(followList)
        }).get()
      })
    } else {
      var condition = event.params.condition
      if (condition.grade)
        condition.grade = _.in(condition.grade)
      if (condition.type)
        condition.type = _.in(condition.type)
      return db.collection('userinfo').skip(event.params.count).limit(LIMIT)
      .where(condition).get()
    }
  } else if (event.type === 'modify') {
    /**
     * 传入
     * event.params.data
     * 或
     * event.params.followMap.from/to/hasFollowed
     */
    if (event.params.data) {
      // 修改部分信息
      var _id = event.params.data._id
      var data = {}
      for (let key in event.params.data) {
        if (key !== '_id') {
          data[key] = event.params.data[key]
        }
      }
      return await db.collection('userinfo')
      .doc(_id)
      .update({
        data: data
      })
    } else if (event.params.followMap) {
      // 修改双向关注状态
      var from = event.params.followMap.from
      var to = event.params.followMap.to
      var hasFollowed = event.params.followMap.hasFollowed
      return await db.collection('userinfo').limit(1).where({
        _openid: to
      }).update({
        data: {
          followed: hasFollowed ? _.pull(from) : _.push([from])
        }
      }).then(res => {
        console.log(hasFollowed)
        console.log(res)
        return db.collection('userinfo').limit(1).where({
          _openid: from
        }).update({
          data: {
            follow: hasFollowed ? _.pull(to) : _.push([to])
          }
        })
      })
    }
      
  } else {
    // 无效分支
    return {}
  }
}