// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  return {
    data: [
      "cloud://xly01-cc001.786c-xly01-cc001-1259811893/LitchiRainbow/swiper/hopeToMeetYou.jpg",
      "cloud://xly01-cc001.786c-xly01-cc001-1259811893/LitchiRainbow/swiper/rainbowFlag.jpg"
    ]
  }
}