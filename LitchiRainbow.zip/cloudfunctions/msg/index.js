// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: "xly01-cc001"
})

const db = cloud.database()
const _ = db.command
const $ = _.aggregate
const LIMIT = 20
const MAX_LIMIT = 100

// 云函数入口函数
exports.main = async (event, context) => {
  console.log(event)
  // 每个分支都需要传入 event.type
  if (event.type === 'get') {
    /** 传入
     * event.params.count
     * event.params.both
    */
    var condition = {
      from: _.in(event.params.both),
      to: _.in(event.params.both)
    }
    if (event.params.count > 0) {
      condition.time = _.or(_.lt(event.params.oldest), _.gt(event.params.latest))
    }
    return await db.collection('msg').limit(LIMIT)
    .where(condition).orderBy('time', 'desc').get()
  } else if (event.type === 'set') {
    /**
     * 传入
     * event.params.data
     */
    event.params.data.time = new Date().getTime()
    return await db.collection('msg').add({
      data: event.params.data
    }).then(res => {
      return {
        data: event.params.data
      }
    })
  } else if (event.type === 'preview') {
    var openid = cloud.getWXContext().OPENID
    const countResult = await db.collection('msg').where(_.or([{
      from: openid
    }, {
      to: openid
    }])).count()
    const total = countResult.total
    if (total == 0) {
      return {
        data: []
      }
    }
    const batchTimes = Math.ceil(total / 100)
    const tasks = []
    for (let i = 0; i < batchTimes; i++) {
      const promise = db.collection('msg').skip(i * MAX_LIMIT).limit(MAX_LIMIT).get()
      tasks.push(promise)
    }
    var res = (await Promise.all(tasks)).reduce((acc, cur) => {
      return {
        data: acc.data.concat(cur.data),
        errMsg: acc.errMsg,
      }
    })
    var fulfilled = new Set()
    for (let i = 0; i < res.data.length; i++) {
      if (res.data[i].from == openid) {
        fulfilled.add(res.data[i].to)
      } else {
        fulfilled.add(res.data[i].from)
      }
    }
    var data = []
    for (let v of fulfilled) {
      data.push(v)
    }
    return db.collection('userinfo').where({
      _openid: _.in(data)
    }).field({
      _openid: true,
      avatar: true,
      nickname: true
    }).get()
  } else {
    // 无效分支
    return {}
  }
}