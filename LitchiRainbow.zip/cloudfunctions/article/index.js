// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  env: "xly01-cc001"
})

const db = cloud.database()
const _ = db.command
const LIMIT = 10
const MAX_LIMIT = 100

// 云函数入口函数
exports.main = async (event, context) => {
  const openid = cloud.getWXContext().OPENID
  console.log(event)
  if (event.type === 'add') {
    event.params.data.time = new Date().getTime()
    return await db.collection('article').add({
      data: event.params.data
    })
  } else if (event.type === 'get') {
    /**
     * 传入
     * event.params.type
     * event.params._id
     * 或
     * event.params.type
     * event.params.count(, event.params._openid, event.params.oldest)
     * 或
     * event.params.type
     * event.params.count(, event.params.oldest)
     */
    if (event.params.type === 'byId') {
      return db.collection('article').doc(event.params._id).get()
    } else if (event.params.type === 'byOpenid') {
      var condition = {
        type: 'article',
        writer: event.params._openid
      }
      if (event.params.count > 0) {
        condition.time = _.lt(event.params.oldest)
      }
      if (event.params._openid != openid) {
        condition.anonymous = false
      }
      return db.collection('article').limit(LIMIT).where(condition).orderBy('time', 'desc').get()
    } else if (event.params.type === 'all') {
      if (event.params.count > 0) {
        return db.collection('article').limit(LIMIT).where({
          type: 'article',
          time: _.lt(event.params.oldest)
        }).orderBy('time', 'desc').get()
      } else {
        return db.collection('article').limit(LIMIT).where({
          type: 'article'
        }).orderBy('time', 'desc').get()
      }
    } else if (event.params.type === 'feedback') {
      if (event.params.count > 0) {
        return db.collection('article').limit(LIMIT).where({
          type: 'feedback',
          time: _.lt(event.params.oldest)
        }).orderBy('time', 'desc').get()
      } else {
        return db.collection('article').limit(LIMIT).where({
          type: 'feedback'
        }).orderBy('time', 'desc').get()
      }
    }
  } else if (event.type === 'modify') {
    /**
     * 传入
     * event.params._id
     * event.params.data 或 event.params.liked
     */
    if (event.params.data) {
      return db.collection('article').doc(event.params._id).update({
        data: event.params.data
      })
    } else {
      return db.collection('article').doc(event.params._id).update({
        data: {
          like: event.params.liked ? _.pull(openid) : _.push([openid])
        }
      })
    }
  } else if (event.type === 'delete') {
    /**
     * 传入
     * event.params._id
     */
    return db.collection('article').doc(event.params._id).get().then(res => {
      var imgList = res.data.imgList
      if (imgList.length == 0) {
        return db.collection('article').doc(event.params._id).remove()
      } else {
        return cloud.deleteFile({
          fileList: imgList
        }).then(res => {
          return db.collection('article').doc(event.params._id).remove()
        })
      }
    })
  }
}