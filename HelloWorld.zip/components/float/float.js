// components/float/float.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    disp_item: [{
      title: "搜索",
      type: "search",
      src: "../../icons/float/search.png"
    }, {
      title: "发布",
      type: "release",
      src: "../../icons/float/release.png"
    }, {
      title: "刷新",
      type: "refresh",
      src: "../../icons/float/refresh.png"
    }, {
      title: "  ",
      type: "more",
      src: "../../icons/float/more.png",
    }],
    folded: false
  },

  /**
   * 组件的方法列表
   */
  methods: {
    tapfloat: function (e) {
      let type = e.currentTarget.dataset.id;
      console.log("bind " + type + " tap...")
      switch (type) {
        case "more":
          this.setData({
            folded: !this.data.folded
          });
          break;
        default:
          break;
      }
    },
  }
})
