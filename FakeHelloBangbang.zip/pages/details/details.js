// pages/details/details.js

const app = getApp()

const util = require('../../utils/util.js')

const md5 = require('../../utils/md5.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    app: app,
    md5: md5,
    order: null,
    pageList: [],
    hideTel: true,
    hideWxid: true,
    hideTake: true
  },

  tapDetailsImage: function (e) {
    wx.previewImage({
      urls: this.data.order.imgList,
      current: this.data.order.imgList[e.currentTarget.dataset.index]
    })
  },

  tapTaken: function (e) {
    let that = this
    console.log('接单成功')
    wx.showToast({
      title: '接单成功',
      success: () => {
        that.setData({
          hideTake: !that.data.hideTake
        }, () => {
          console.log('进入订单进度页面')
        })
      }
    })
  },

  tapTake: function (e) {
    this.setData({
      hideTake: !this.data.hideTake
    })
  },

  tapContact: function (e) {
    if (e.currentTarget.dataset.copytype == 'tel') {
      this.setData({
        hideTel: !this.data.hideTel
      })
    } else {
      this.setData({
        hideWxid: !this.data.hideWxid
      })
    }
  },

  tapCopy: function (e) {
    wx.setClipboardData({
      data: this.data.hideTel ? this.data.order.userInfo.wxid : this.data.order.userInfo.tel
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let orderId = parseInt(options.orderId)
    // 以后尝试数据库获取订单信息
    for (let obj of app.globalData.allItems) {
      if (obj.ids.orderId == orderId) {
        let order = {
          ids: obj.ids,
          userInfo: obj.userInfo,
          title: {
            text: obj.content.title
          },
          append: {
            text: '￥' + obj.content.price.now,
            color: 'red'
          },
          price: obj.content.price,
          mapList: obj.mapList,
          imgList: obj.imgList
        }
        switch (obj.ids.typeId) {
          case 0:
            order.append = {
              text: app.globalData.subPageList[obj.ids.typeId][obj.ids.subTypeId],
              color: app.globalData.mainColor[0]
            }
            break
          case 1:
            break
          case 2:
            order.mapList[order.mapList.length - 1].K = '求助内容'
            order.remark = {
              text: '求助截止时间：' + util.formatDatetime(new Date(obj.time.endTime)),
              color: app.globalData.mainColor[0]
            }
            break
          case 3:
            order.remark = {
              text: obj.remark.read + '人浏览&emsp;&emsp;' + obj.remark.collect +  '人收藏',
              color: '#CCC'
            }
            break
          case 4:
            if (obj.ids.statId != 0)
              order.append = {
                text: '已有人接单',
                color: '#CCC'
              }
            order.mapList[order.mapList.length - 1].K = '外卖内容'
            order.remark = {
              text: '外卖截止时间：' + util.formatDatetime(new Date(obj.time.endTime)),
              color: app.globalData.mainColor[0]
            }
            break
        }
        this.setData({
          order: order
        })
        break
      }
    }
    this.setData({
      pageList: app.globalData.pageList,
      orderMD5: md5.hexMD5('' + orderId).slice(0, 16),
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})