// pages/home/home.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    app: app,
    swiperImgList: [
      '/images/swiper/1.png',
      '/images/swiper/2.png',
      '/images/swiper/3.png',
      '/images/swiper/4.png'
    ],
    pageList: [],
    releaseIconSrc: '/icons/default/release.png',
    releaseLightAnim: null,
    releaseToastAnim: null,
    hideRelease: true
  },

  tapEasyReleaseItem: function (e) {
    let index = e.currentTarget.dataset.index
    wx.navigateTo({
      url: '/pages/release/release?typeId=' + index,
    })
  },

  tapEasyReleaseCancel: function (e) {
    this.setData({
      hideRelease: !this.data.hideRelease
    })
  },

  tapEasyReleaseBtn: function (e) {
    let that = this
    let anim = wx.createAnimation({
      duration: 50,
      timingFunction: 'linear'
    })
    anim.scale(0.1, 0.1).step()
    that.setData({
      releaseToastAnim: anim.export()
    }, () => {
      setTimeout(() => {
        that.setData({
          hideRelease: !that.data.hideRelease
        }, () => {
          anim = wx.createAnimation({
            duration: 300,
            timingFunction: 'ease-out'
          })
          anim.scale(1, 1).step()
          that.setData({
            releaseToastAnim: anim.export()
          }, () => {
            setTimeout(() => {
              anim = wx.createAnimation({
                duration: 20,
                timingFunction: 'linear'
              })
              anim.scale(0.95, 0.95).step()
              that.setData({
                releaseToastAnim: anim.export()
              }, () => {
                setTimeout(() => {
                  anim = wx.createAnimation({
                    duration: 20,
                    timingFunction: 'linear'
                  })
                  anim.scale(1, 1).step()
                  that.setData({
                    releaseToastAnim: anim.export()
                  })
                }, 20)
              })
            }, 300)
          })
        })
      }, 50)
    })
  },

  tapToSquare: function (e) {
    let index = e.currentTarget.dataset.index
    if (index < 5)
      wx.navigateTo({
        url: '/pages/square/square?curPageIndex=' + index
      })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      pageList: app.globalData.pageList
    })
    this.releaseLightAnim = wx.createAnimation({
      duration: 1400,
      timingFunction: 'linear'
    })
    let next = true
    setInterval(function () {
      if (next) {
        this.releaseLightAnim.scale(1.3, 1.3).step()
      } else {
        this.releaseLightAnim.scale(1, 1).step()
      }
      next = !next
      this.setData({
        releaseLightAnim: this.releaseLightAnim.export()
      })
    }.bind(this), 1400)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.globalData.curThis = this
    this.setData({
      hideRelease: true
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})