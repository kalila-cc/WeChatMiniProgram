// pages/release/release.js

const app = getApp()

var util = require('../../utils/util.js')

var md5 = require('../../utils/md5.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    app: app,
    typeId: 0,
    agreeWithTerms: true,
    hideAgreeWithTerms: true,
    hideSuccessRelease: true,
    disabledSubmit: false
  },

  submitForm: function (e) {
    let that = this
    that.setData({
      disabledSubmit: !that.data.disabledSubmit
    })
    let db = wx.cloud.database({
      throwOnNotFond: false
    })
    if (!this.data.agreeWithTerms) {
      this.setData({
        hideAgreeWithTerms: !this.data.hideAgreeWithTerms
      }, () => {
        setTimeout(() => {
          that.setData({
            hideAgreeWithTerms: !this.data.hideAgreeWithTerms
          })
        }, 1000)
      })
      return
    }
    let contains = (arr, ele) => {
      let len = arr.length
      for (let i = 0; i < len; ++i)
        if (arr[i] == ele)
          return i
    }
    let value = e.detail.value
    let now_tsp = new Date().getTime()
    let order = {
      _id: '' + (app.globalData.allItems.length + 1),
      ids: {
        orderId: app.globalData.allItems.length + 1,
        typeId: this.data.typeId,
        subTypeId: 0,
        statId: 0,
        openid: app.globalData.userInfo.openid
      },
      userInfo: {
        avatarUrl: app.globalData.userInfo.avatarUrl,
        nickName: app.globalData.userInfo.nickName,
        tel: app.globalData.userInfo.tel,
        wxid: app.globalData.userInfo.wxid
      },
      content: {
        title: 'title',
        price: {
          before: 0,
          now: 0
        }
      },
      imgList: [],
      mapList: [],
      time: {
        submitTime: now_tsp,
        takeTime: 0,
        durTime: {
          start: 0,
          end: 0
        },
        confirmTime: 0,
        cancelTime: 0,
        endTime: 0
      },
      remark: {
        read: 0,
        collect: 0,
        more: null,
        showSeal: true
      }
    }
    for (let key in value) {
      let keyArr = key.split('_')
      switch (keyArr.length) {
        case 1:
          order[keyArr[0]] = value[key]
          break
        case 2:
          order[keyArr[0]][keyArr[1]] = value[key]
          break
        case 3:
          order[keyArr[0]][keyArr[1]][keyArr[2]] = value[key]
          break
        default:
          break
      }
    }
    switch (this.data.typeId) {
      case 0:
        order.content.title = order.content.title.V
        order.time.endTime = now_tsp + 1000 * 86400 * 7
        order.ids.subTypeId = contains(app.globalData.subPageList[0], order.ids.subTypeId.V)
        order.mapList[0].K = ''
        order.remark.showSeal = false
        order.ids.statId = 1
        break
      case 1:
        order.content.title = order.mapList[4].V
        order.mapList[0].K = '快递所在点'
        order.mapList[2].K = '快递重量'
        order.mapList[4].K = '宿舍地址'
        order.remark.more = order.remark.more.V
        order.time.endTime = order.time.durTime.end
        break
      case 2:
        order.content.title = order.content.title.V
        order.mapList[1].K = '求助内容'
        break
      case 3:
        order.content.title = order.content.title.V
        order.ids.subTypeId = contains(app.globalData.subPageList[3], order.ids.subTypeId.V)
        order.mapList[1].K = ''
        order.remark.showSeal = false
        break
      case 4:
        order.content.title = order.content.title.V
        order.mapList[0].K = ''
        order.ids.statId = 1
        break
      default:
        break
    }
    order.userInfo.name = order.userInfo.name.V
    order.userInfo.wxid = order.userInfo.wxid.V
    order.imgList = order.imgList || []
    // 订单加入数据库
    db.collection('demo-03-order').count().then(res => {
      var cnt = res.total + 1
      order._id = '' + cnt
      order.ids.orderId = cnt
      db.collection('demo-03-order').add({
        data: order
      }).then(async res => {
        let i = 0
        for (let img of order.imgList) {
          console.log('读取文件成功，尝试上传文件: ' + img)
          let suffix = img.slice(img.lastIndexOf('.'))
          let filename = md5.hexMD5(app.globalData.userInfo._openid) + new Date().getTime() + i
          let path = 'demo-03/order/' + order.ids.typeId + '/' + filename + suffix
          wx.cloud.uploadFile({
            cloudPath: path,
            filePath: img,
            success: (res) => {
              console.log('上传文件成功，尝试获取 URL')
              wx.cloud.getTempFileURL({
                fileList: [res.fileID],
                success: (res) => {
                  let url = res.fileList[0].tempFileURL
                  db.collection('demo-03-order').where({
                    'ids.orderId': order.ids.orderId
                  }).update({
                    data: {
                      ['imgList.' + i]: url
                    }
                  })
                  console.log('成功上传图片，链接为：' + url)
                  i++
                },
                fail: (err) => {
                  console.log('获取 URL 失败')
                  console.log(err)
                }
              })
            },
            fail: (err) => {
              console.log('上传文件失败')
              console.log(err)
            }
          })
        }
      }).then(res => {
        wx.cloud.callFunction({
          name: 'getDemo03Data',
          data: {
            skip: app.globalData.allItems.length
          },
          success: res => {
            console.log('更新本地数据成功')
            app.globalData.allItems = res.result.concat(app.globalData.allItems)
            wx.navigateBack({})
          },
          fail: err => {
            console.log('更新本地数据失败')
            console.log(err)
            wx.navigateBack({})
          }
        })
      })
    })
    // 收尾工作
    that.setData({
      hideSuccessRelease: !that.data.hideSuccessRelease
    }, () => {
      setTimeout(() => {
        that.setData({
          hideSuccessRelease: !that.data.hideSuccessRelease
        }, () => {
          console.log('上传订单完成')
        })
      }, 1000)
    })
    // 此处结束同步数据库

    // 后面的代码备份一份到注释，防止无法恢复
    /*
    app.globalData.allItems.unshift(order)
    that.setData({
      hideSuccessRelease: !that.data.hideSuccessRelease
    }, () => {
      app.globalData.curThis.setData({
        allItems: app.globalData.allItems
      }, () => {
        that.setData({
          hideSuccessRelease: !that.data.hideSuccessRelease
        }, () => {
          wx.cloud.database().collection('demo-03-order').add({
            data: order,
            success: (res) => {
              console.log('上传订单完成')
              wx.navigateBack()
            }
          })
        })
      })
    })
    */
  },

  tapAgreeWithTermsIcon: function (e) {
    this.setData({
      agreeWithTerms: !this.data.agreeWithTerms
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      typeId: options.typeId ? parseInt(options.typeId) : 0
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})