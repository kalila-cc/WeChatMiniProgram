// pages/individual/individual.js

const app = getApp()

var util = require('../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    app: app,
    userInfo: app.globalData.userInfo,
    individualList: [{
      src: '/icons/individual/userInfo.png',
      text: '个人信息'
    },{
      src: '/icons/individual/balance.png',
      text: '我的余额'
    },{
      src: '/icons/individual/mark.png',
      text: '闲置收藏'
    },{
      src: '/icons/individual/feedback.png',
      text: '意见反馈'
    },{
      src: '/icons/individual/service.png',
      text: '联系客服'
    }],
    quickSetUserInfoCount: 1
  },

  tapIndividualOption: function (e) {
    let infoId = e.currentTarget.dataset.infoid
    if (infoId < 3)
      wx.navigateTo({
        url: '/pages/private/private?infoId=' + infoId,
      })
  },

  longtapQuickSetUserInfo: function () {
    this.data.quickSetUserInfoCount++
    if (this.data.quickSetUserInfoCount % 4 == 0) {
      app.globalData.userInfo.name = '开发者'
      app.globalData.userInfo.grade = '保密'
      app.globalData.userInfo.profession = '保密'
      app.globalData.userInfo.wxid = 'wxid_xxxxxxx'
      app.globalData.userInfo.tel = '17876581824'
      app.globalData.userInfo.campusAuth = true
    } else {
      app.globalData.userInfo.name = undefined
      app.globalData.userInfo.grade = undefined
      app.globalData.userInfo.profession = undefined
      app.globalData.userInfo.wxid = undefined
      app.globalData.userInfo.tel = undefined
      app.globalData.userInfo.campusAuth = undefined
    }
  },

  tapPreviewAvatar: function (e) {
    wx.previewImage({
      urls: [this.data.userInfo.avatarUrl],
      current: this.data.userInfo.avatarUrl
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      userInfo: app.globalData.userInfo
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})