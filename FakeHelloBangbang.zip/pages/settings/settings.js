// pages/settings/settings.js

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    app: app,
    propId: 1,
    prop: null,
    neverPick: true,
    hideModifiedError: true,
    hideCorrectError: true,
    hideSelectError: true
  },

  submitForm: function (e) {
    let val = e.detail.value
    let that = this
    let propId = that.data.propId
    switch (propId) {
      case 3:
        if (!that.data.neverPick) {
          app.globalData.userInfo.gender = val.picker + 1
          wx.cloud.callFunction({
            name: 'setDemo03UserInfo',
            data: {
              K: that.data.prop.type,
              V: val.picker + 1
            },
            success: res => {
              console.log('更改信息成功')
              console.log(res)
              wx.navigateBack({})
            },
            fail: err => {
              console.log('更改信息失败')
              console.log(err)
            }
          })
        } else {
          console.log('未作出选择，不更新数据')
          that.setData({
            hideSelectError: !that.data.hideSelectError
          }, () => {
            setTimeout(() => {
              that.setData({
                hideSelectError: !that.data.hideSelectError
              })
            }, 1000)
          })
        }
        break;
      case 7:
        break;
      default:
        if (val.input.length>0) {
          app.globalData.userInfo[that.data.prop.type] = val.input
          wx.cloud.callFunction({
            name: 'setDemo03UserInfo',
            data: {
              K: that.data.prop.type,
              V: val.input
            },
            success: res => {
              console.log('更改信息成功')
              console.log(res)
            },
            fail: err => {
              console.log('更改信息失败')
              console.log(err)
            }
          })
          wx.navigateBack({})
        } else {
          if (propId <= 5) {
            that.setData({
              hideModifiedError: !that.data.hideModifiedError
            }, () => {
              setTimeout(() => {
                that.setData({
                  hideModifiedError: !that.data.hideModifiedError
                })
              }, 1000)
            })
          } else {
            that.setData({
              hideCorrectError: !that.data.hideCorrectError
            }, () => {
              setTimeout(() => {
                that.setData({
                  hideCorrectError: !that.data.hideCorrectError
                })
              }, 1000)
            })
          }
        }
        break;
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let propId = options.propId === undefined ? 1 : parseInt(options.propId)
    this.setData({
      propId: propId
    })
    let prop = {}
    switch (propId) {
      case 1:
        prop.name = '昵称'
        prop.type = 'nickName'
        prop.data = app.globalData.userInfo.nickName
        prop.placeholder = '请输入您的昵称'
        break;
      case 2:
        prop.name = '姓名'
        prop.type = 'name'
        prop.data = app.globalData.userInfo.name
        prop.placeholder = '请输入您的姓名'
        break;
      case 3:
        prop.name = '性别'
        prop.type = 'gender'
        prop.data = app.globalData.userInfo.gender
        prop.list = ['男', '女']
        prop.placeholder = '请选择您的性别'
        break;
      case 4:
        prop.name = '年级',
        prop.type = 'grade'
        prop.data = app.globalData.userInfo.grade
        prop.placeholder = '请输入您的年级'
        break;
      case 5:
        prop.name = '专业',
        prop.type = 'profession'
        prop.data = app.globalData.userInfo.profession
        prop.placeholder = '请输入您的专业'
        break;
      case 6:
        prop.name = '微信号',
        prop.type = 'wxid'
        prop.data = app.globalData.userInfo.wxid
        prop.placeholder = '请输入您的微信号'
        break;
      case 7:
        prop.name = '手机号码',
        prop.type = 'tel'
        prop.data = app.globalData.userInfo.tel
        prop.placeholder = ['请输入您的手机号码', '请输入手机验证码']
        break;
      default:
        break;
    }
    this.setData({
      prop: prop
    })
  },

  changePicker: function (e) {
    this.setData({
      ['prop.data']: parseInt(e.detail.value) + 1,
      neverPick: false
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})