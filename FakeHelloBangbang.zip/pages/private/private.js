// pages/private/private.js

const app = getApp()

const md5 = require('../../utils/md5.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    app: app,
    infoId: 0,
    userInfoList: [],
    titles: ['个人信息', '我的余额', '闲置收藏'],
    balance: 0.00,
    balance_str: '',
    collections: [],
    hideBalanceNotEnoughError: true
  },

  tapUserInfoDetailItem: function (e) {
    let that = this
    let propId = e.currentTarget.dataset.propid
    switch (propId) {
      case 0:
        wx.chooseImage({
          count: 1,
          success: function (res) {
            let img = res.tempFilePaths[0]
            wx.cloud.uploadFile({
              cloudPath: 'demo-03/user/avatar/' + md5.hexMD%(app.globalData.userInfo._openid) + new Date().getTime() + img.slice(img.lastIndexOf('.')),
              filePath: img,
              success: res => {
                console.log('private: 上传头像成功')
                console.log(res)
                let fileid = res.fileID
                wx.cloud.getTempFileURL({
                  fileList: [fileid],
                  success: res => {
                    console.log('private: 获取头像链接成功')
                    console.log(res)
                    let url = res.fileList[0].tempFileURL
                    wx.cloud.callFunction({
                      name: 'setDemo03UserInfo',
                      data: {
                        K: 'avatarUrl',
                        V: {
                          fileid: fileid,
                          url: url
                        }
                      },
                      success: res => {
                        console.log('private: 更新头像数据库数据成功')
                        console.log(res)
                        app.globalData.userInfo.avatarUrl = url
                        that.setData({
                          'userInfoList[0].data': url
                        })
                      },
                      fail: err => {
                        console.log('private: 更新头像数据库数据失败')
                        console.log(err)
                      }
                    })
                  },
                  fail: err => {
                    console.log('private: 获取头像链接失败')
                    console.log(err)
                  }
                })
              },
              fail: err => {
                console.log('private: 上传头像失败')
                console.log(err)
              }
            })
          }
        })
        break
      case 8:
        break
      default:
        wx.navigateTo({
          url: '/pages/settings/settings?propId=' + propId,
        })
    }
  },

  tapWithdraw: function (e) {
    let that = this
    if (that.data.balance < 2) {
      that.setData({
        hideBalanceNotEnoughError: !that.data.hideBalanceNotEnoughError
      }, () => {
        setTimeout(() => {
          that.setData({
            hideBalanceNotEnoughError: !that.data.hideBalanceNotEnoughError
          })
        }, 2000)
      })
    }
  },

  init: function () {
    let uil = this.data.userInfoList
    for (let i = 0; i < uil.length; ++i) {
      if (uil[i].data === undefined || uil[i].data === null)
        continue
      switch (uil[i].type) {
        case 'nickName':
        case 'grade':
        case 'profession':
        case 'wxid':
          uil[i].text = uil[i].data
          break;
        case 'name':
          uil[i].text = uil[i].data.charAt(0) + '*'.repeat(uil[i].data.length - 1)
          break;
        case 'gender':
          if (uil[i].data == 1)
            uil[i].text = '男'
          else if (uil[i].data == 2)
            uil[i].text = '女'
          break;
        case 'tel':
          let number_str = uil[i].data.toString()
          if (number_str.length == 11) {
            uil[i].text = number_str.slice(0, 3) + '****' + number_str.slice(7)
          } else {
            let plusStarLen = number_str.length > 2 ? (number_str.length - 2) : 1
            uil[i].text = number_str.charAt(0) + '*'.repeat(plusStarLen) + number_str.charAt(number_str.length - 1)
          }
          break;
        case 'campusAuth':
          if (uil[i].data)
            uil[i].text = '已认证'
          else
            uil[i].text = '未认证'
          break;
        default:
          break;
      }
    }
    this.setData({
      userInfoList: uil
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this
    that.setData({
      infoId: parseInt(options.infoId),
      balance_str: that.data.balance.toFixed(2)
    })
    that.setData({
      userInfoList: [{
        title: '头像',
        type: 'avatarUrl',
        data: getApp().globalData.userInfo.avatarUrl,
        text: ''
      }, {
        title: '昵称',
        type: 'nickName',
        data: getApp().globalData.userInfo.nickName,
        text: ''
      }, {
        title: '姓名',
        type: 'name',
        data: getApp().globalData.userInfo.name,
        text: ''
      }, {
        title: '性别',
        type: 'gender',
        data: getApp().globalData.userInfo.gender,
        text: ''
      }, {
        title: '年级',
        type: 'grade',
        data: getApp().globalData.userInfo.grade,
        text: ''
      }, {
        title: '专业',
        type: 'profession',
        data: getApp().globalData.userInfo.profession,
        text: ''
      }, {
        title: '微信号',
        type: 'wxid',
        data: getApp().globalData.userInfo.wxid,
        text: ''
      }, {
        title: '手机号码',
        type: 'tel',
        data: getApp().globalData.userInfo.tel,
        text: ''
      }, {
        title: '校园认证',
        type: 'campusAuth',
        data: getApp().globalData.userInfo.campusAuth,
        text: ''
      }]
    }, () => {
      that.init()
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.globalData.curThis = this
    let that = this
    that.setData({
      userInfoList: [{
        title: '头像',
        type: 'avatarUrl',
        data: getApp().globalData.userInfo.avatarUrl,
        text: ''
      }, {
        title: '昵称',
        type: 'nickName',
        data: getApp().globalData.userInfo.nickName,
        text: ''
      }, {
        title: '姓名',
        type: 'name',
        data: getApp().globalData.userInfo.name,
        text: ''
      }, {
        title: '性别',
        type: 'gender',
        data: getApp().globalData.userInfo.gender,
        text: ''
      }, {
        title: '年级',
        type: 'grade',
        data: getApp().globalData.userInfo.grade,
        text: ''
      }, {
        title: '专业',
        type: 'profession',
        data: getApp().globalData.userInfo.profession,
        text: ''
      }, {
        title: '微信号',
        type: 'wxid',
        data: getApp().globalData.userInfo.wxid,
        text: ''
      }, {
        title: '手机号码',
        type: 'tel',
        data: getApp().globalData.userInfo.tel,
        text: ''
      }, {
        title: '校园认证',
        type: 'campusAuth',
        data: getApp().globalData.userInfo.campusAuth,
        text: ''
      }]
    }, () => {
      that.init()
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})