// pages/square/square.js

const app = getApp()

var util = require('../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    app: app,
    innerSwiper: ['/images/inner-swiper/1.png'],
    pageList: [],
    subPageList: [],
    allItems: [],
    curPageIndex: 2,
    curSubPageIndexList: [0, 0, 0, 0, 0 ,0]
  },

  tapSubScroll: function (e) {
    let curSubPageIndex = e.detail.curSubPageIndex
    this.data.curSubPageIndexList[this.data.curPageIndex] = curSubPageIndex
    this.setData({
      curSubPageIndexList: this.data.curSubPageIndexList
    })
  },

  tapItem: function (e) {
    let orderId = e.currentTarget.dataset.orderid
    wx.navigateTo({
      url: '/pages/details/details?orderId=' + orderId
    })
  },

  /**
   * 监听子页面变化
   */
  changeMultiPageSwiper: function (e) {
    console.log('square: ' + this.data.pageList[this.data.curPageIndex].cn + ' 的子页面因滑动而发生变化')
    let subPageIndex = e.detail.current
    this.data.curSubPageIndexList[this.data.curPageIndex] = subPageIndex
    this.setData({
      curSubPageIndexList: this.data.curSubPageIndexList
    })
  },

  /**
   * 监听主页面变化
   */
  tapScrollView: function (e) {
    let index = e.currentTarget.dataset.index
    if (index != this.data.curPageIndex) {
      console.log('square: 主页面由 ' + this.data.pageList[this.data.curPageIndex].cn + ' 更新至 ' + this.data.pageList[index].cn)
      this.setData({
        curPageIndex: index
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (!(options.curPageIndex === undefined)) {
      this.setData({
        curPageIndex: parseInt(options.curPageIndex)
      })
    }
    this.setData({
      allItems: app.globalData.allItems,
      pageList: app.globalData.pageList,
      subPageList: app.globalData.subPageList
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    app.globalData.curThis = this
    this.setData({
      allItems: app.globalData.allItems
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})