// components/float/float.js

const app = getApp()

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    curPageIndex: {
      type: Number,
      value: 0
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    disp_item: [{
      title: "搜索",
      type: "search",
      src: "../../icons/float/search.png"
    }, {
      title: "发布",
      type: "release",
      src: "../../icons/float/release.png"
    }, {
      title: "刷新",
      type: "refresh",
      src: "../../icons/float/refresh.png"
    }, {
      title: "  ",
      type: "more",
      src: "../../icons/float/more.png",
    }],
    folded: false
  },

  /**
   * 组件的方法列表
   */
  methods: {
    tapfloat: async function (e) {
      let type = e.currentTarget.dataset.id;
      console.log("float: bind " + type + " tap...")
      switch (type) {
        case "more":
          this.setData({
            folded: !this.data.folded
          });
          break;
        case 'release':
          wx.navigateTo({
            url: '/pages/release/release?typeId=' + (this.properties.curPageIndex),
          })
          break;
        case 'refresh':
          console.log('float/tapfloat/refresh: ')
          await wx.cloud.callFunction({
            name: 'getDemo03Data',
            data: {
              skip: app.globalData.allItems.length
            },
            success: res => {
              app.globalData.curThis.setData({
                allItems: res.result.concat(app.globalData.allItems)
              })
            }
          })
          break
        default:
          break
      }
      console.log(app.globalData.allItems)
    },
  }
})
