// components/sub-scroll/sub-scroll.js

const app = getApp()

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    subPageTitle: {
      type: Array,
      value: []
    },
    curSubPageIndex: {
      type: Number,
      value: 1
    },
    selectedColor: {
      type: String,
      value: app.globalData.mainColor[0]
    },
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    tapSubScroll: function (e) {
      let beforeSubPageIndex = this.data.curSubPageIndex
      let curSubPageIndex = e.currentTarget.dataset.index
      this.setData({
        curSubPageIndex: curSubPageIndex
      })
      console.log('当前页面的子页面因点击而由 ' + this.data.subPageTitle[beforeSubPageIndex] + ' 更新至 ' + this.data.subPageTitle[curSubPageIndex])
      this.triggerEvent('tapSubScroll', {
        curSubPageIndex: curSubPageIndex
      })
    }
  }
})
