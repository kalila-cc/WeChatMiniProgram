// components/navbar/navbar.js

const app = getApp()

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    showBack: {
      type: Boolean,
      value: false
    },
    title: {
      type: String,
      value: 'title'
    },
    color: {
      type: String,
      value: app.globalData.mainColor[0]
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    backIconSrc: '/icons/navbar/back.png',
    homeIconSrc: '/icons/navbar/home.png',
    navHeight: app.globalData.navHeight,
    imgSize: app.globalData.navHeight / 4
  },

  /**
   * 组件的方法列表
   */
  methods: {
    tapback: function() {
      wx.navigateBack({
        fail: (res) => {
          console.log(res)
          console.log('返回失败')
        }
      })
    }
  }
})
