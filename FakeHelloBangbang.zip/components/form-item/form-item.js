// components/form-item/form-item.js

const app = getApp()

const util = require('../../utils/util.js')

Component({
  behaviors: ['wx://form-field'],
  /**
   * 组件的属性列表
   */
  properties: {
    typeId: {
      type: String,
      value: 'title'
    },
    must: {
      type: Boolean,
      value: true
    },
    title: {
      type: Object,
      value: {
        main: '标题',
        append: '附加信息'
      }
    },
    placeholder: {
      type: Object,
      value: {
        content: '内容',
        clamp: 1,
        maxlength: 140,
      }
    },
    pickerList: {
      type: Array,
      value: [{
        title: '默认标题 1',
        content: ['默认选项 1', '默认选项 2']
      }, {
        title: '默认标题 2',
        content: ['默认选项 3', '默认选项 4']
      }]
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    app: app,
    util: util,
    tmpImgList: ['/icons/default/uploadImage.png'],
    pickerIndex: -1,
    pickerIndexList: [0, 0],
    picker2dArray: [],
    neverPick: true,
    today: null,
    oneWeekLater: null,
    today_str: '',
    oneWeekLater_str: '',
    selectedDatetime: ['', ''],
    durationIndexList: [[-1, -1], [-1, -1]],
    hideDatetimeError: true,
    hideDurationError: true,
    value: {}
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // input
    inputMonitor: function (e) {
      this.setData({
        value: {
          K: this.properties.title.main,
          V: e.detail.value
        }
      })
    },
    // number
    numberMonitor: function (e) {
      this.setData({
        value: e.detail.value
      })
    },
    // money
    moneyMonitor: function (e) {
      this.setData({
        value: parseFloat(e.detail.value)
      })
    },
    // image
    tapUploadImage: function (e) {
      let that = this
      wx.chooseImage({
        count: 10 - that.data.tmpImgList.length,
        sizeType: ['compressed'],
        success: function(res) {
          let uploadImageIconUrl = that.data.tmpImgList.pop()
          that.data.tmpImgList = that.data.tmpImgList.concat(res.tempFilePaths)
          that.setData({
            value: that.data.tmpImgList
          })
          that.data.tmpImgList.push(uploadImageIconUrl)
          that.setData({
            tmpImgList: that.data.tmpImgList
          })
        }
      })
    },
    // picker
    changePicker1dMonitor: function (e) {
      this.setData({
        pickerIndex: parseInt(e.detail.value),
        value: {
          K: this.properties.title.main,
          V: this.data.pickerList[parseInt(e.detail.value)]
        }
      })
    },
    changePicker2dMonitor: function (e) {
      let value = e.detail.value
      this.setData({
        neverPick: false,
        pickerIndexList: value,
        value: {
          K: this.properties.title.main,
          V: this.data.pickerList[value[0]].title + ' ' + this.data.pickerList[value[0]].content[value[1]]
        }
      })
    },
    columnChangeMonitor: function (e) {
      let col = e.detail.column
      let val = e.detail.value
      if (col == 0) {
        this.setData({
          picker2dArray: [this.properties.pickerList.map(e => { return e.title }), this.properties.pickerList[val].content],
          pickerIndexList: [val, 0],
          value: this.data.pickerList[val].content
        })
      }
    },
    // datetime
    changeDateMonitor: function (e) {
      if (this.data.selectedDatetime[1].length==0) {
        this.setData({
          ['selectedDatetime[0]']: e.detail.value,
          value: new Date(e.detail.value + ' ' + this.data.selectedDatetime[1]).getTime()
        })
      } else {
        let that =this
        let selectedDay = new Date(e.detail.value + ' ' + that.data.selectedDatetime[1])
        if (new Date().getTime() < selectedDay.getTime()) {
          that.setData({
            ['selectedDatetime[0]']: e.detail.value,
            value: new Date(e.detail.value + ' ' + this.data.selectedDatetime[1]).getTime()
          })
        } else {
          that.setData({
            hideDatetimeError: !that.data.hideDatetimeError
          }, () => {
            setTimeout(() => {
              that.setData({
                hideDatetimeError: !that.data.hideDatetimeError
              })
            }, 2000)
          })
        }
      }
    },
    changeTimeMonitor: function (e) {
      if (this.data.selectedDatetime[0].length == 0) {
        this.setData({
          ['selectedDatetime[1]']: e.detail.value,
          value: new Date(this.data.selectedDatetime[0] + ' ' + e.detail.value).getTime()
        })
      } else {
        let that = this
        let selectedDay = new Date(that.data.selectedDatetime[0] + ' ' + e.detail.value)
        if (new Date().getTime() < selectedDay.getTime()) {
          that.setData({
            ['selectedDatetime[1]']: e.detail.value,
            value: new Date(this.data.selectedDatetime[0] + ' ' + e.detail.value).getTime()
          })
        } else {
          that.setData({
            hideDatetimeError: !that.data.hideDatetimeError
          }, () => {
            setTimeout(() => {
              that.setData({
                hideDatetimeError: !that.data.hideDatetimeError
              })
            }, 2000)
          })
        }
      }
    },
    // duration
    changeDurationStartMonitor: function (e) {
      let tfmt = tpl => (tpl[0] ? util.formatDate(this.data.tomorrow) : util.formatDate(this.data.today)) + ' ' + this.data.durationPoints[1][tpl[1]]
      let tsp = tpl => (new Date(tfmt(tpl))).getTime()
      let start = e.detail.value
      let end = this.data.durationIndexList[1]
      if (start[0] >=0 && start[1] >= 0) {
        if (end[0] >= 0 && end[1] >= 0) {
          if (tsp(start) < tsp(end)) {
            this.setData({
              ['durationIndexList[0]']: start,
              ['value.start']: tsp(start)
            })
          } else {
            let that = this
            that.setData({
              hideDurationError: !that.data.hideDurationError
            }, () => {
              setTimeout(() => {
                that.setData({
                  hideDurationError: !that.data.hideDurationError
                })
              }, 2000)
            })
          }
        } else {
          this.setData({
            ['durationIndexList[0]']: start,
            ['value.start']: tsp(start)
          })
        }
      }
    },
    changeDurationEndMonitor: function (e) {
      let tfmt = tpl => (tpl[0] ? util.formatDate(this.data.tomorrow) : util.formatDate(this.data.today)) + ' ' + this.data.durationPoints[1][tpl[1]]
      let tsp = tpl => (new Date(tfmt(tpl))).getTime()
      let end = e.detail.value
      let start = this.data.durationIndexList[0]
      if (end[0] >= 0 && end[1] >= 0) {
        if (start[0] >= 0 && start[1] >= 0) {
          if (tsp(start) < tsp(end)) {
            this.setData({
              ['durationIndexList[1]']: end,
              ['value.end']: tsp(end)
            })
          } else {
            let that = this
            that.setData({
              hideDurationError: !that.data.hideDurationError
            }, () => {
              setTimeout(() => {
                that.setData({
                  hideDurationError: !that.data.hideDurationError
                })
              }, 2000)
            })
          }
        } else {
          this.setData({
            ['durationIndexList[1]']: end,
            ['value.end']: tsp(end)
          })
        }
      }
    }
  },

  lifetimes: {
    attached: function () {
      if (this.properties.typeId == 'picker-2d') {
        this.setData({
          pickerIndexList: [0, 0],
          picker2dArray: [this.properties.pickerList.map(e => { return e.title }), this.properties.pickerList[0].content]
        })
      } else if (this.properties.typeId == 'picker-1d') {
      } else if (this.properties.typeId == 'datetime') {
        let today = new Date()
        this.setData({
          today: today,
          oneWeekLater: util.passDays(today, 7),
          today_str: util.formatDate(today),
          oneWeekLater_str: util.formatDate(util.passDays(today, 7)),
        })
      } else if (this.properties.typeId == 'duration') {
        let today = new Date()
        let tomorrow = util.passDays(today, 1)
        let getTimePoints = e => util.formatNumber((e + 9) + '') + ':00'
        let getDayPoints = e => '(' + util.formatDateWithoutYear(e) + ')'
        let dayPoints = ['今天' + getDayPoints(today), '明天' + getDayPoints(tomorrow)]
        let timePoints = util.range(15).map(getTimePoints)
        let durationPoints = [dayPoints, timePoints]
        this.setData({
          today: today,
          tomorrow: tomorrow,
          durationPoints: durationPoints
        })
      }
    }
  }
})
