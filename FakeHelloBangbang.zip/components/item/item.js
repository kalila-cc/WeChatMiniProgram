// components/item/item.js

const app = getApp()

var util = require('../../utils/util.js')

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    orderId: {
      type: Number,
      value: 1
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    app: app,
    util: util,
    msg: null
  },

  /**
   * 组件的方法列表
   */
  methods: {

  },

  lifetimes: {
    attached: function (options) {
      let order = app.globalData.allItems[app.globalData.allItems.length - this.properties.orderId]
      let ids = order.ids
      let content = order.content
      let imgList = order.imgList
      let mapList = order.mapList
      let time = order.time
      let remark = order.remark
      let msg = {
        ids: ids,
        title: {
          text: content.title,
          weight: 'bold'
        },
        append: {
          text: '￥' + content.price.now,
          color: 'red',
          size: 34
        },
        imgList: imgList,
        mapList: mapList,
        time: time,
        remark: {
          size: 29,
          color: app.globalData.mainColor[0]
        },
        mainClamp: 2,
        showSeal: true
      }
      switch (ids.typeId) {
        case 0:
          msg.title.weight = 'normal'
          msg.append = {
            text: app.globalData.subPageList[0][ids.subTypeId],
            color: app.globalData.mainColor[0],
            size: 30
          }
          msg.showSeal = false
          break
        case 1:
          msg.mapList = [
            mapList[0],
            mapList[1],
            {
              K: '最晚送达时间',
              V: util.formatDatetime(new Date(time.endTime)) + ' 之前',
            }
          ]
          msg.remark.text = '备注：' + (remark.more.length > 0 ? remark.more : '暂无')
          break
        case 2:
          msg.remark.text = '求助截止时间：' + util.formatDatetime(new Date(time.endTime))
          break
        case 3:
          msg.mapList = [mapList[1]]
          msg.remark = {
            text: remark.read + '人浏览&emsp;&emsp;' + remark.collect + '人收藏',
            color: '#CCC',
            size: 25
          }
          msg.showSeal = false
          break
        case 4:
          msg.remark.text = '外卖截止时间：' + util.formatDatetime(new Date(time.endTime))
          break
        default:
          break
      }
      this.setData({
        msg: msg
      })
    }
  }
})