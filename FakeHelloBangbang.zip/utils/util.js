
const md5 = require('md5.js')

const app = getApp()

const formatDatetime = datetime => {
  const year = datetime.getFullYear()
  const month = datetime.getMonth() + 1
  const day = datetime.getDate()
  const hour = datetime.getHours()
  const minute = datetime.getMinutes()

  return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

const formatDate = datetime => {
  const year = datetime.getFullYear()
  const month = datetime.getMonth() + 1
  const day = datetime.getDate()

  return [year, month, day].map(formatNumber).join('-')
}

const formatTime = datetime => {
  const hour = datetime.getHours()
  const minute = datetime.getMinutes()

  return [hour, minute].map(formatNumber).join(':')
}

const formatDateWithoutYear = datetime => {
  const month = datetime.getMonth() + 1
  const day = datetime.getDate()

  return [month, day].map(formatNumber).join('-')
}

const passDays = (datetime, day) => {
  return new Date((datetime.getTime() + 1000 * (86400 * day)))
}

const range = function (len) {
  return Array.from({length: len}, (_, index) => index)
}

module.exports = {
  formatNumber: formatNumber,
  formatDate: formatDate,
  formatTime: formatTime,
  formatDatetime: formatDatetime,
  formatDateWithoutYear: formatDateWithoutYear,
  passDays: passDays,
  range: range
}
