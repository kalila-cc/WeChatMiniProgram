//app.js
const util = require('/utils/util.js')

wx.cloud.init()

App({
  onLaunch: function () {
    let that = this
    // 获取数据库信息
    wx.cloud.callFunction({
      name: 'getDemo03Data',
      data: {
        skip: 0
      },
      success: (res) => {
        console.log('获取数据库信息成功')
        console.log(res)
        that.globalData.allItems = res.result
      },
      fail: (err) => {
        console.log('获取数据库信息失败')
        console.log(err)
      }
    })
    // 获取系统信息
    wx.getSystemInfo({
      success: res => {
        if (res.platform == 'ios')
          that.globalData.navHeight = res.statusBarHeight + 44
        else if (res.platform == 'android')
          that.globalData.navHeight = res.statusBarHeight + 48
        else
          that.globalData.navHeight = res.statusBarHeight + 46
        that.globalData.screenHeight = res.screenHeight
        that.globalData.clientHeight = res.windowHeight - that.globalData.navHeight
        that.globalData.tabbarHeight = res.screenHeight - that.globalData.navHeight - that.globalData.clientHeight
        that.globalData.rpx2px = res.windowWidth / 750
      },
      fail: err => {
        console.log(err)
      }
    })
    // 获取 openid
    wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('app/onLaunch: 成功登录')
        console.log(res)
        // 获取用户信息
        wx.cloud.callFunction({
          name: 'getDemo03UserInfo',
          data: {},
          success: (res) => {
            console.log('app/onLaunch: 成功获取 userInfo')
            console.log(res)
            that.globalData.userInfo = res.result.data[0]
            that.globalData.userInfo.avatarUrl = that.globalData.userInfo.avatarUrl[0].url
          },
          fail: (err) => {
            console.log('app/onLaunch: 无法获取 userInfo')
            console.log(err)
          }
        })
      },
      fail: err => {
        console.log('app/onLaunch: 无法获取 openid')
        console.log(err)
      }
    })
    // 通知数据
    console.log('app/onLaunch: 初始化信息如下（不包括云函数信息）')
    console.log(that.globalData)
  },
  globalData: {
    userInfo: {},
    navHeight: 0,
    clientHeight: 0,
    rpx2px: 1, 
    allItems: [],
    mainColor: ['#FEC459', '#FFF3C9'],
    curThis: null,
    pageList: [{
      id: 0,
      cn_simple: '公益',
      cn: '帮帮公益',
      en: 'public',
      icons: [
        '/icons/home/public.png',
        '/icons/order/public.png',
        '/icons/release/public.png'
      ]
    }, {
      id: 1,
      cn_simple: '快递',
      cn: '帮帮快递',
      en: 'express',
      icons: [
        '/icons/home/express.png',
        '/icons/order/express.png',
        '/icons/release/express.png'
      ]
    }, {
      id: 2,
      cn_simple: '求助',
      cn: '帮帮求助',
      en: 'help',
      icons: [
        '/icons/home/help.png',
        '/icons/order/help.png',
        '/icons/release/help.png'
      ]
    }, {
      id: 3,
      cn_simple: '闲置',
      cn: '帮帮闲置',
      en: 'free',
      icons: [
        '/icons/home/free.png',
        '/icons/order/free.png',
        '/icons/release/free.png'
      ]
    }, {
      id: 4,
      cn_simple: '外卖',
      cn: '帮帮外卖',
      en: 'takeaway',
      icons: [
        '/icons/home/takeaway.png',
        '/icons/order/takeaway.png',
        '/icons/release/takeaway.png'
      ]
    }, {
      id: 5,
      cn_simple: '玩乐',
      cn: '吃喝玩乐',
      en: 'recreation',
      icons: [
        '/icons/home/recreation.png',
        '/icons/order/recreation.png',
        '/icons/release/recreation.png'
      ]
    }],
    subPageList: [
      ['全部', '寻物启事', '失物招领', '找队友'],
      [],
      [],
      ['全部', '化妆品', '衣服', '生活类', '学习类', '其他'],
      [],
      []
    ],
  }
})

/*
订单对象的属性接口如下
order: {
    _id:          // 数据库编号（从 1 开始）
    ids: {
      orderId:    // 订单唯一标识
      typeId:     // 订单主类型唯一表示（从 0 开始）
      subTypeId:  // 订单子类型唯一标识（从 1 开始）
      statId:     // 订单状态唯一标识  （从 0 开始）
      openid:     // 用户身份唯一标识
    },
    userInfo: {
      avatarUrl:  // 用户头像
      nickName:   // 用户昵称
      tel:        // 用户手机号码
      wxid:       // 用户微信号码
    },
    content: {
      title:    // 标题
      price: {
        before: // 原价
        now:    // 现价
      }
    },
    imgList: // 图片链接数组（长度不超过 9）
    mapList: // KV 对象数组，K 为标题，V 为内容
    time: {
      submitTime: // 订单提交时间
      takeTime:   // 订单接单时间
      durTime:  // 订单持续时间
      confirmTime:// 订单确认时间
      cancelTime: // 订单取消时间
      endTime:    // 订单截止时间
    },
    remark: {
      read:       // 阅读量
      collect:    // 收藏量
      more:       // 更多备注文字
      showSeal:   // 是否显示订单状态水印
    }
  }
*/