// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  var db = cloud.database()
  return await db.collection('demo-03-order').skip(event.skip).count()
  .then(res => {
    return res.total
  }).then(async res => {
    let ans = []
    let times = Math.ceil((res - event.skip) / 20)
    for (let i = 0; i < times; i++) {
      await db.collection('demo-03-order').skip(event.skip + i * 20).limit(20).get().then(res => {
        ans = res.data.reverse().concat(ans)
      })
    }
    return ans
  })
}