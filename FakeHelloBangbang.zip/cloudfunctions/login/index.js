// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  var db = cloud.database()
  var openid = cloud.getWXContext().OPENID
  return new Promise((resolve, reject) => {
    db.collection('demo-03-user').limit(1).where({
      _openid: openid
    }).count().then(res => {
      if (res.total == 0) {
        console.log('注册新用户')
        cloud.getTempFileURL({
          fileList: ['cloud://xly01-cc001.786c-xly01-cc001-1259811893/demo-03/icons/default/avatar.png']
        }).then(res => {
          console.log('成功获取头像 url')
          console.log('url: ' + res.fileList[0].tempFileURL)
          return res.fileList[0].tempFileURL
        }).then(async res => {
          console.log('尝试将新用户加入数据库')
          return await db.collection('demo-03-user').add({
            data: {
              _openid: '' + openid,
              avatarUrl: [{
                fileid: 'cloud://xly01-cc001.786c-xly01-cc001-1259811893/demo-03/icons/default/avatar.png',
                url: res
              }],
              nickName: '新用户' + new Date().getTime(),
              gender: 0,
              campusAuth: false
            }
          })
        }).then(res => {
          console.log('新用户加入数据库后，返回 openid')
          resolve(openid)
        })
      } else {
        console.log('直接返回 openid')
        resolve(openid)
      }
    })
  })
}