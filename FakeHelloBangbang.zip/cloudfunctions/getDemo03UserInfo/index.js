// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()

// 云函数入口函数
exports.main = async (event, context) => {
  db = cloud.database()
  return await db.collection('demo-03-user').limit(1).where({
    _openid: cloud.getWXContext().OPENID,
  }).get()
}