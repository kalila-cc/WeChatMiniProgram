const cloud = require('wx-server-sdk')
cloud.init({
  env: 'marwall-ixou8'
})
const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  if (event.mode == 'delete') { // 删除 check 记录(传入 mode, checkid, applicant)
    return await db.collection('check').where({
      checkid: event.checkid
    }).remove().then(res => {
      // 删除 userinfo 记录
      db.collection('userinfo').where({
        openid: event.applicant
      }).update({
        'status.check': _.pull(event.checkid)
      })
    })
  } else if (event.mode == 'reply') { // 回复 check(传入 mode, checkid)
    return await db.collection('check').where({
      checkid: event.checkid
    }).update({
      data: {
        reply: event.reply,
        pass: event.pass,
        done: true
      }
    })
  }
}