// pages/user/admin/admin.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nav:[
      {title:'认证状态',child:['全部','已认证','待认证','未认证']},
      {title:'用户数据',child:['列表','搜索']},
      {title:'管理员',child:[]},
    ],
    modifyItem:[
      {key:'realname',title:'姓名'},
      {key:'gender',title:'性别'},
      {key:'campus',title:'学校'},
      {key:'grade',title:'年级'},
      {key:'tel',title:'手机号'},
      {key:'nickname',title:'昵称'},
      {key:'wxid',title:'微信号'},
      {key:'qq',title:'qq号'},
    ],
    selectNav:{first:0,second:0},
    userinfo:[],
    checkIndex:-1,
    animationData:{},
    timer:true,
    searchValue:null,
    pickerIndex:0,
    limit:20,
    isEnd:false
    
  },
  changeNav(e){
    let kind = e.target.dataset.kind
    let index = parseInt(e.target.dataset.index)
    this.setData({
      [`selectNav.${kind}`]:index,
      userinfo:[],
      isEnd:false,
      searchValue:null
    })
    
    if(kind == 'first'){//点击一级导航
      switch(index){
        case 0 : this.getCertificationList();break;
        case 1 : this.getUserList();break;
        case 2 : this.getAdminList();break;
      }
    }
    else if(this.data.selectNav.first==0){//点击认证状态二级导航
      this.getCertificationList(index)
    }else if(this.data.selectNav.first==1){//点击用户数据二级导航
      switch(index){
        case 0 : this.getUserList();break;
        case 1 : this.setData({userinfo:[]})
      }
    }

    
  },
  getCertificationList(sortKey){
    console.log('cer')

    let that = this
    wx.showLoading({
      title: '获取列表中',
      mask:true
    })
    wx.cloud.callFunction({
      name:'getCertificationList',
      data:{
        skip:that.data.userinfo.length,
        limit:that.data.limit,
        sortKey:sortKey
      }
    }).then(res=>{
      let tmp = res.result.data
      //1:已认证，2：待认证，3：未认证
      if(tmp.length){
        for(var i in tmp){
          tmp[i].status = tmp[i].certification?1:tmp[i].certificationimg?2:3
        }
        that.setData({
          userinfo:that.data.userinfo.concat(tmp)
        })
      }else{
        that.setData({
          isEnd:true
        })
     }
      wx.hideLoading()

    }).catch(err=>{
      console.log(err)
      wx.hideLoading()
    })
  },
  getUserList(){
    let that = this
    wx.showLoading({
      title: '获取列表中',
      mask:true
    })
    console.log(123)
    wx.cloud.callFunction({
      name:'getUserList',
      data:{
        skip:that.data.userinfo.length,
        limit:that.data.limit
      }
    }).then(res=>{
      if(res.result.data.length)
        that.setData({
          userinfo:that.data.userinfo.concat(res.result.data)
        })
      else
        that.setData({
          isEnd:true
        })
      console.log(that.data.userinfo)
      wx.hideLoading()
    }).catch(err=>{
      console.log(err)
      wx.hideLoading()
    })
  },
  getAdminList(){
    let that = this
    wx.showLoading({
      title: '获取列表中',
      mask:true
    })

    wx.cloud.callFunction({
      name:'getAdminList'
    }).then(res=>{
      that.setData({
        userinfo:res.result.data
      })
      console.log(2233,that.data.userinfo)
      wx.hideLoading()
    }).catch(err=>{
      console.log(err)
      wx.hideLoading()
    })
  },
  getSearchList(){
    let that = this
    wx.showLoading({
      title: '搜索中',
      mask:true
    })
 
    wx.cloud.callFunction({
      name:'searchUserinfo',
      data:{
        searchValue:that.data.searchValue,
        searchAttribute:that.data.modifyItem[that.data.pickerIndex].key,
        skip:that.data.userinfo.length,
        limit:that.data.limit
      }
    }).then(res=>{
      if(res.result.data.length)
        that.setData({
          userinfo:that.data.userinfo.concat(res.result.data)
        })
      else
        that.setData({
          isEnd:true
        })
      wx.hideLoading()

    }).catch(err=>{
      console.log(err)
      wx.hideLoading()
    })
  },
  search(){
    if(this.data.searchValue){
      this.setData({
        userinfo:[]
      })
      this.getSearchList()
    }
      
  },
  changeAdmin(e){
    let index = e.currentTarget.dataset.index
    let that = this
    let organization = this.data.userinfo[index].organization
    console.log(organization)
    let indexof = organization.indexOf('admin')
    var flag = 0//1代表授予权限，0代表取消权限
    if(indexof==-1)
      flag = 1
    wx.showModal({
      title: '修改权限',
      content: '是否'+(flag?'授予':'删除')+that.data.userinfo[index].realname+'管理员权限',
      showCancel: true,
      success: res => {
        if (res.confirm) {
          if(flag)
            organization.push('admin')
          else
            organization.splice(indexof,1);
          that.update(index)
      }
    }
    })
      
  },
  changeInfo(e){
    let index = e.currentTarget.dataset.index
    let key = e.currentTarget.dataset.key
    this.setData({
      [`userinfo[${index}].${key}`]:e.detail.value
    })
  },
  changeSearch(e){
    this.setData({
      searchValue:e.detail.value
    })
  },
  changePicker(e){
    this.setData({
      pickerIndex:e.detail.value
    })
  },
  update(index) {
    let that = this
    let data = this.data.userinfo[index]
    wx.showLoading({
      title: '保存中',
      mask: true
    })
    var tmpInfo={}
    for (var i in data)
      if(i!='_id')
        tmpInfo[i]=data[i]
    wx.cloud.callFunction({
      name: "updateInfo",
      data: {
        _id: data._id,
        tmpInfo: tmpInfo
      },
      success: res => {
        console.log('info: 上传个人信息成功')
        that.setData({
          [`userinfo[${index}]`] : data
        })
        wx.hideLoading()
        wx.showToast({
          title: '保存成功',
          icon: 'none'
        })
      },
      fail: err => {
        console.log('info: 上传个人信息失败')
        console.log(err)
        wx.hideLoading()
        wx.showToast({
          title: '保存失败，请重试',
          icon: 'none'
        })
      }
    })
  },
  updateText(e){
    let index = e.currentTarget.dataset.index
    this.update(index)
  },
  onPreviewImage(e) {
    let that = this
    wx.previewImage({
      urls: [that.data.userinfo[that.data.checkIndex].certificationimg],
      current: that.data.userinfo[that.data.checkIndex].certificationimg
    })
  },
  checkCertificationimg(e){
  let index = e.currentTarget.dataset.index
  let that =this
  let checkIndex = this.data.checkIndex
  let timer = this.data.timer
  if(timer){ 
    var animation_down  = wx.createAnimation({
      duration:200,
      timingFunction:'linear'
    })
    var animation_up  = wx.createAnimation({
      duration:100,
      timingFunction:'linear'
    })
    animation_down.height('500rpx').step()
    animation_up.height(0).step()
    this.data.timer = false
    if(checkIndex!=-1){
      this.setData({
        animationData: animation_up.export()
      })
      setTimeout(() => {
        if(index == checkIndex)
          this.setData({
            checkIndex:-1,
            timer:true
          })
        else{
          this.setData({
            checkIndex:index
          })
          this.setData({
            animationData: animation_down.export()
          })
          setTimeout(() => {
            that.data.timer = true
        }, 200)
        }
        
      }, 100)
    }
    else{
      this.setData({
        checkIndex:index
      })
      this.setData({
        animationData: animation_down.export()
      })
      setTimeout(() => {
          that.data.timer = true
      }, 200)
    }
  }
    
  },
  changeCertification(e){
    let that = this
    let key = e.currentTarget.dataset.key
    let index = e.currentTarget.dataset.index
    let _id = this.data.userinfo[index]._id
    let certification,certificationimg = this.data.userinfo[index].certificationimg
    switch(key){
      case '1':  certification = true//通过认证
                    break                 
      case '3':  certificationimg = null//认证失败
                    certification = false
                    break
      case '2':certification = false//取消认证
                    break
                                    
    }
    console.log('here')
    wx.showLoading({
      title: '修改中',
      mask:true
    })
    wx.cloud.callFunction({
      name:'changeCertification',
      data:{
        _id:_id,
        certificationimg:certificationimg,
        certification:certification
      }
    }).then(res=>{
      that.setData({
        [`userinfo[${index}].certificationimg`]:certificationimg,
        [`userinfo[${index}].certification`]:certification,
        [`userinfo[${index}].status`]:key
      })
      wx.hideLoading()
      wx.showToast({
        title: '修改成功',
        icon: 'none'
      })
    }).catch(err=>{
      console.log(err)
      wx.hideLoading()
      wx.showToast({
        title: '修改失败',
        icon: 'none'
      })
    })
  },
  
  //触底刷新函数
  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {
    this.getCertificationList(0)
  },

  onReachBottom: function () {
    if(!this.data.isEnd){
      if(this.data.selectNav.first == 0){
        this.getCertificationList(this.data.selectNav.second)
      }
      else if(this.data.selectNav.first==1){
        switch(this.data.selectNav.second){
          case 0 : this.getUserList();break;
          case 1 : this.getSearchList();break;
        }
      }
    }else{
      wx.showToast({
        title: '已无更多结果',
        icon: 'none'
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})