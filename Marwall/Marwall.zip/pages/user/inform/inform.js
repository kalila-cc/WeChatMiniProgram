// pages/square/square.js

const app = getApp()
const util = require('../../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    app: app,
    userinfoData: [],
    applicantName: [],
    label: [],
    order: [],
    label_index: 0,
    order_index: 0,
    type: null,
    lock: {
      applyOperation: false,
      feedbackOperation: false,
      reportOperation: false
    }
  },

  // 删除元素
  deleteElement: function (arr, key, val) {
    let i = -1
    if (key != 'self') {
      for (let j = 0; j < arr.length; j++) {
        if (arr[j][key] == val) {
          i = j
          break
        }
      }
    } else {
      for (let j = 0; j < arr.length; j++) {
        if (arr[i] == val) {
          i = j
          break
        }
      }
    }
    if (i >= 0)
      arr.splice(i, 1)
    return arr
  },

  // 删除反馈/举报
  onDeleteItem: function (e) {
    if (this.data.lock.feedbackOperation || this.data.lock.reportOperation)
      return
    var type = e.currentTarget.dataset.type
    var that = this
    if (type == 'feedback') {
      this.data.lock.feedbackOperation = true
      let feedbackid = e.currentTarget.dataset.feedbackid
      let feedbackedby = e.currentTarget.dataset.feedbackedby
      wx.cloud.callFunction({
        name: 'deleteData',
        data: {
          type: 'feedback',
          feedbackid: feedbackid,
          feedbackedby: feedbackedby
        },
        success: res => {
          console.log('inform: 删除反馈成功')
          wx.showToast({
            title: '删除成功',
            icon: 'none'
          })
          that.setData({
            userinfoData: that.deleteElement(that.data.userinfoData, 'feedbackid', feedbackid)
          })
          that.deleteElement(app.globalData.userinfo.status.feedback, 'self', feedbackid)
          this.data.lock.feedbackOperation = false
        },
        fail: err => {
          console.log('inform: 删除反馈失败')
          console.log(err)
          wx.showToast({
            title: '删除失败，请重试',
            icon: 'none'
          })
          this.data.lock.feedbackOperation = false
        }
      })
    } else if (type == 'report') {
      this.data.lock.reportOperation = true
      let reportid = e.currentTarget.dataset.reportid
      let reportedby = e.currentTarget.dataset.feedbackedby
      let reportobj = e.currentTarget.dataset.reportobj
      wx.cloud.callFunction({
        name: 'deleteData',
        data: {
          type: 'feedback',
          reportid: reportid,
          reportedby: reportedby,
          reportobj: reportobj
        },
        success: res => {
          console.log('inform: 删除举报成功')
          wx.showToast({
            title: '删除成功',
            icon: 'none'
          })
          that.setData({
            userinfoData: that.deleteElement(that.data.userinfoData, 'reportid', reportid)
          })
          that.deleteElement(app.globalData.userinfo.status.report, 'self', reportid)
          this.data.lock.reportOperation = false
        },
        fail: err => {
          console.log('inform: 删除举报失败')
          console.log(err)
          wx.showToast({
            title: '删除失败，请重试',
            icon: 'none'
          })
          this.data.lock.reportOperation = false
        }
      })
    }
  },

  // 请求操作
  onApplyOperation: function (e) {
    if (this.data.lock.applyOperation)
      return
    var that = this
    var index = e.currentTarget.dataset.index
    var checkid = e.currentTarget.dataset.checkid
    var applicant =  e.currentTarget.dataset.applicant
    this.data.lock.applyOperation = true
    if (index == 0) { // 删除
      wx.cloud.callFunction({
        name: 'updateCheck',
        data: {
          checkid: checkid,
          mode: 'delete',
          applicant: applicant
        },
        success: res => {
          console.log('inform: 删除收到请求成功')
          wx.showToast({
            title: '删除成功',
            icon: 'none'
          })
          that.setData({
            userinfoData: that.deleteElement(that.data.userinfoData, 'checkid', checkid)
          })
          that.deleteElement(app.globalData.userinfo.status.check, 'self', checkid)
          that.data.lock.applyOperation = false
        },
        fail: err => {
          console.log('inform: 删除收到请求失败')
          console.log(err)
          wx.showToast({
            title: '删除失败，请重试',
            icon: 'none'
          })
          that.data.lock.applyOperation = false
        }
      })
    } else if (index == 1 || index == 2) {  // 拒绝/接受
      let content = ''
      let userinfo = app.globalData.userinfo
      let selectedType = ''
      // 询问回复内容
      if (index == 2) {
        wx.showActionSheet({
          itemList: ['发送QQ', '发送微信', '发送电话'],
          success: res => {
            console.log('inform: 选择发送信息类型成功')
            if (res.tapIndex == 0) {
              selectedType = 'qq'
            } else if (res.tapIndex == 1) {
              selectedType = 'wxid'
            } else if (res.tapIndex == 2) {
              selectedType = 'tel'
            }
            // 确定回复内容
            if (index == 2) {
              if (selectedType == '') {
                that.data.lock.applyOperation = false
                return
              } else if (selectedType == 'qq') {
                if (userinfo.qq) {
                  content = 'QQ: ' + userinfo.qq
                } else {
                  wx.showToast({
                    title: '你的QQ信息未补全，请先前往个人信息页补全',
                    icon: 'none',
                    duration: 5000
                  })
                  that.data.lock.applyOperation = false
                  return
                }
              } else if (selectedType == 'wxid') {
                if (userinfo.wxid) {
                  content = '微信: ' + userinfo.wxid
                } else {
                  wx.showToast({
                    title: '你的微信信息未补全，请先前往个人信息页补全',
                    icon: 'none',
                    duration: 5000
                  })
                  that.data.lock.applyOperation = false
                  return
                }
              } else if (selectedType == 'tel') {
                if (userinfo.tel) {
                  content = '电话: ' + userinfo.tel
                } else {
                  wx.showToast({
                    title: '你的电话信息未补全，请先前往个人信息页补全',
                    icon: 'none',
                    duration: 5000
                  })
                  that.data.lock.applyOperation = false
                  return
                }
              }
            }
            // 上传处理状态
            wx.cloud.callFunction({
              name: 'updateCheck',
              data: {
                checkid: checkid,
                mode: 'reply',
                pass: Boolean(index == 2),
                reply: index == 1 ? {} : {
                  content: content
                }
              },
              success: res => {
                console.log('inform: 同意/拒绝申请成功')
                for (let obj of that.data.userinfoData) {
                  if (obj.checkid == checkid) {
                    obj.done = true
                    that.setData({
                      userinfoData: that.data.userinfoData
                    })
                    break
                  }
                }
                wx.showToast({
                  title: '操作成功',
                  icon: 'none'
                })
                that.data.lock.applyOperation = false
              },
              fail: err => {
                console.log('inform: 同意/拒绝申请失败')
                console.log(err)
                wx.showToast({
                  title: '操作失败，请重试',
                  icon: 'none'
                })
                that.data.lock.applyOperation = false
              }
            })
          },
          fail: err => {
            console.log('inform: 选择发送信息类型失败')
            console.log(err)
            wx.showToast({
              title: '请选择其中一个联系方式发送',
              icon: 'none'
            })
          }
        })
      }
    }
  },

  onLabel: function (e) {
    let index = e.currentTarget.dataset.index
    this.setData({
      userinfoData: []
    })
    if (index == 0) {
      this.setData({
        label_index: index,
        order: ['收到', '发出'],
        order_index: 0
      })
    } else if (index == 1) {
      this.setData({
        label_index: index,
        order:['反馈', '举报'], 
        order_index: 0
      })
    }
    this.getUserInfoData()
  },

  onOrder: function (e) {
    let order_index = e.currentTarget.dataset.index
    if (order_index != this.data.order_index) {
      this.setData({
        order_index: order_index,
        userinfoData: []
      })
      this.getUserInfoData()
    }
  },

  /*获取申请 */
  getUserInfoData: function () {
    let that = this
    wx.cloud.callFunction({
      name: 'getApplyData',
      data: {
        label_index: that.data.label_index,
        order_index: that.data.order_index
      },
      success: res => {
        console.log('inform: 调用函数 getApplyData 成功')
        // 格式化时间/类型
        var typeMaps = {
          userinfo: '申请获取联系方式',
          admin: '申请成为管理员',
          joinCommunity: '申请加入社团',
          setCommunity: '申请建立社团'
        }
        if (that.data.label_index == 0) { // 我的申请
          for (let obj of res.result.data) {
            obj.checkedtime_fmt = util.formatTime(new Date(obj.checkedtime))
            obj.type_fmt = typeMaps[obj.type]
          }
        } else if (that.data.label_index == 1) {  // 反馈和举报
          if (that.data.order_index == 0) { // 反馈
            for (let obj of res.result.data) {
              obj.feedbackedtime_fmt = util.formatTime(new Date(obj.feedbackedtime))
              obj.type_fmt = typeMaps[obj.type]
            }
          } else if (that.data.order_index == 1) {  // 举报
            for (let obj of res.result.data) {
              obj.reportedtime_fmt = util.formatTime(new Date(obj.reportedtime))
              obj.type_fmt = typeMaps[obj.type]
            }
          }
        }
        console.log(res.result.data)
        that.setData({
          userinfoData: res.result.data
        })
      },
      fail: err => {
        console.log('inform: 调用函数 getApplyData 失败')
        console.log(err)
        wx.showToast({
          title: '加载失败，请重试',
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '我的消息'
    })
    this.setData({
      type: '',
      label: ['我的请求', '反馈和举报'],
      order: ['收到', '发出']
    })
    this.getUserInfoData()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})