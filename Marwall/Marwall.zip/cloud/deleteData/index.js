const cloud = require('wx-server-sdk')
cloud.init({
  env: "marwall-ixou8"
})
const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  if (event.type == 'post') { //  删除帖子(传入 postid, postedby, comment, report)
    // 先删除帖子
    return await db.collection('post').limit(1).where({
        postid: event.postid
    }).remove().then(res => {
      // 遍历评论
      for (let commentid of event.comment) {
        // 获取评论的举报
        db.collection('comment').where({
            commentid: commentid
        }).get().then(res => {
          // 删除评论的举报
          let report = res.data[0].status.report
          db.collection('report').where({
            reportid: _.in(report)
          }).remove()
        })
        db.collection('comment').where({
          commentid: commentid
        }).remove()
      }
      // 删除帖子的举报
      db.collection('report').where({
        reportid: _.in(event.report)
      }).remove()
      // 删除帖子发布者的帖子记录
      db.collection('userinfo').where({
        openid: event.postedby
      }).update({
        data: {
          'status.post': _.pull(event.postid)
        }
      })
    })
  } else if (event.type == 'comment') { // 删除评论(传入 commentid, commentedby, report)
    // 通过 commentid 计算 postid
    let start_index = String(new Date().getTime()).length
    let length = String(new Date().getTime()).length + cloud.getWXContext().OPENID.length
    let postid = event.commentid.substr(start_index, length)
    // 先删除帖子的评论记录
    return await db.collection('post').where({
      postid: postid
    }).update({
      data: ({
        'status.comment': _.pull(event.commentid)
      })
    }).then(res => {
      // 删除评论
      db.collection('comment').where({
        commentid: event.commentid
      }).remove().then(res => {
        // 删除评论的举报
        db.collection('report').where({
          reportid: _.in(event.report)
        }).remove()
      })
      // 删除评论发布者的评论记录
      db.collection('userinfo').where({
        openid: event.commentedby
      }).update({
        data: {
          'status.comment': _.pull(event.commentid)
        }
      })
    })
  } else if (event.type == 'feedback') {  // 删除反馈(传入 feedbackid, feedbackedby)
    return await db.collection('feedback').where({
      feedbackid: event.feedbackid
    }).remove().then(res => {
      // 删除 userinfo 记录
      db.collection('userinfo').where({
        openid: event.feedbackedby
      }).update({
        data: {
          'status.feedback': _.pull(event.feedbackid)
        }
      })
    })
  } else if (event.type == 'report') {  // 删除举报(传入 reportid, reportedby, reportobj)
    // 删除 report 记录
    return await db.collection('report').where({
      reportid: event.reportid
    }).remove().then(res => {
      // 删除 userinfo 记录
      db.collection('userinfo').where({
        openid: event.reportedby
      }).update({
        data: {
          'status.report': _.pull(event.reportid)
        }
      }).then(res => {
        // 计算 id
        let id = event.reportid.substr(String(new Date().getTime).length)
        id = id.splice(0, id.length - cloud.getWXContext().OPENID.length)
        // 删除 post/comment 记录
        if (event.reportobj == 'post') {
          db.collection('post').where({
            postid: id
          }).update({
            data: {
              'status.report': _.pull(id)
            }
          })
        } else if (event.reportobj == 'comment') {
          db.collection('comment').where({
            commentid: id
          }).update({
            data: {
              'status.report': _.pull(id)
            }
          })
        }
      })
    })
  }
}