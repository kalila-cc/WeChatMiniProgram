const cloud = require('wx-server-sdk')
cloud.init({
  env: "marwall-ixou8"
})
const db = cloud.database()
const MAX_LIMIT = 20

// 云函数入口函数
exports.main = async (event, context) => {
  var openid = cloud.getWXContext().OPENID
  var ret = []
  if (event.label_index == 0) { // 我的请求
    if (event.order_index == 0) { // 收到
      await db.collection("check").where({
        data: {
          reviewer: openid
        },
      }).orderBy('checkedtime', 'desc')
      .limit(MAX_LIMIT).get().then(res => {
        ret = res
      })
    } else if (event.order_index == 1) {  // 发出
      await db.collection("check").where({
        data: {
          applicant: openid
        },
      }).orderBy('checkedtime', 'desc')
      .limit(MAX_LIMIT).get().then(res => {
        ret = res
      })
    }
  } else if (event.label_index == 1) {  // 反馈和举报
    if (event.order_index == 0) { // 反馈
      await db.collection("feedback").where({
        feedbackedby: openid,
      }).orderBy('feedbackedtime', 'desc')
      .limit(MAX_LIMIT).get().then(res => {
        ret = res
      })
    } else if (event.order_index == 1) {  // 举报
      await db.collection("report").where({
        reportedby: openid,
      }).orderBy('feedbackedtime', 'desc')
      .limit(MAX_LIMIT).get().then(res => {
        ret = res
      })
    }
  } else if (event.label_index == 2) {
    await db.collection("check").where({
      data: {
        done: Boolean(event.order_index == 0 || event.order_index == 2),
        pass: Boolean(event.order_index == 2),
      }
    }).orderBy('checkedtime', 'desc').get().then(res => {
      ret = res
    })
  }
  return ret
}