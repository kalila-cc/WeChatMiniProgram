//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },
  globalData: {
    userInfo: null,
    videoList: [{
      videoId: 1,
      cover: "../../images/cover/1.png",
      title: "10分钟了解曹丕南征，魏军兵分三路，刘备病逝白帝城【白话三国志：21】",
      url: "../detail/detail"
    }, {
      videoId: 2,
      cover: "../../images/cover/2.png",
      title: "【万物拣史】新冠疫情被列为PHEIC后，中国会被“封锁”多久？",
      url: "../detail/detail"
    }, {
      videoId: 3,
      cover: "../../images/cover/3.png",
      title: "你的口罩到货了吗？口罩交易有哪些套路？？？【J酱】",
      url: "../detail/detail"
    }, {
      videoId: 4,
      cover: "../../images/cover/4.png",
      title: "十六国战纪-第七章-奴隶皇帝石勒的发家史",
      url: "../detail/detail"
    }, {
      videoId: 5,
      cover: "../../images/cover/5.png",
      title: "【TED演讲】女孩儿不必完美，只是需要更有勇气",
      url: "../detail/detail"
    }, {
      videoId: 6,
      cover: "../../images/cover/6.png",
      title: "【科技袁人PLUS】心理学：故意隐瞒病情的，是哪类人？",
      url: "../detail/detail"
    }, {
      videoId: 7,
      cover: "../../images/cover/7.png",
      title: "【两不疑】史上最蠢皇帝和史上最帅气皇后，情人节完整版PV心动上线",
      url: "../detail/detail"
    }, {
      videoId: 8,
      cover: "../../images/cover/8.png",
      title: "【催泪/蜡笔小新】请不要忘记这些泪点的瞬间，真的很暖！",
      url: "../detail/detail"
    }]
  }
})